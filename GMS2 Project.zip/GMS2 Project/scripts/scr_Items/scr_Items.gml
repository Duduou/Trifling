function item_add(_item)
{
	var exist_in_array = false;
	for(var i = 0; i < array_length(_item.slot); i++)
	{
		if(_item.slot[i] == _item)
		{
			exist_in_array = true;	
		}
	}
	if(exist_in_array = false && _item != obj_Player.equiped_weapon && _item != obj_Player.equiped_armor && _item != obj_Player.equiped_accessory1 && _item != obj_Player.equiped_accessory2)
	{
	if array_length(_item.slot) == 0
	{
		array_push(_item.slot, _item);	
	}
	else
	{
		array_insert(_item.slot, 1,_item);	
	}
	}
	else
	{
		_item.stack += 1; 	
	}
}
#region EQUIPS
function equip_armor(_item, _position)
{
	if(obj_Player.equiped_armor == global.item_list.none)
	{
		array_delete(obj_Item_Manager.inventory_armor, _position, 1);
		array_insert(obj_Item_Manager.inventory_armor, 0, global.item_list.none);
		obj_Player.equiped_armor = _item;
	}
	else if(obj_Menu.op_length9 == 1)
	{
		array_delete(obj_Item_Manager.inventory_armor, _position, 1);
		array_insert(obj_Item_Manager.inventory_armor, 0,obj_Player.equiped_armor);
		obj_Player.equiped_armor = _item;
	}
	else
	{
		array_delete(obj_Item_Manager.inventory_armor, _position, 1);
		array_insert(obj_Item_Manager.inventory_armor, 1,obj_Player.equiped_armor);
		obj_Player.equiped_armor = _item;
	}
}
function equip_weapon(_item, _position)
{
	if(obj_Player.equiped_weapon == global.item_list.empty)
	{
		array_delete(obj_Item_Manager.inventory_weapon, _position, 1);
		array_insert(obj_Item_Manager.inventory_weapon, 0, global.item_list.empty);
		obj_Player.equiped_weapon = _item;
	}
	else if(obj_Menu.op_length8 == 1)
	{
		array_delete(obj_Item_Manager.inventory_weapon, _position, 1);
		array_insert(obj_Item_Manager.inventory_weapon, 0,obj_Player.equiped_weapon);
		obj_Player.equiped_weapon = _item;
	}
	else
	{
		array_delete(obj_Item_Manager.inventory_weapon, _position, 1);
		array_insert(obj_Item_Manager.inventory_weapon, 1,obj_Player.equiped_weapon);
		obj_Player.equiped_weapon = _item;
	}
}
function equip_accessory1(_item, _position)
{
	//array_delete(obj_Item_Manager.inventory_accessory, _position, 1);
	//array_insert(obj_Item_Manager.inventory_accessory, 0, global.item_list.none);
	//obj_Player.equiped_accessory1 = _item;
	//array_push(obj_Item_Manager.inventory_accessory, obj_Player.equiped_accessory1);
	if!(_item == global.item_list.none && obj_Player.equiped_accessory1 == global.item_list.none)
	{
		if(obj_Player.equiped_accessory2 == global.item_list.none && obj_Player.equiped_accessory1 == global.item_list.none && _item == global.item_list.none)
		{
			
		}
		else if(obj_Player.equiped_accessory2 == global.item_list.none && obj_Player.equiped_accessory1 == global.item_list.none && _item != global.item_list.none)
		{
			array_delete(obj_Item_Manager.inventory_accessory, _position, 1);
			array_insert(obj_Item_Manager.inventory_accessory, 0, global.item_list.none);
			obj_Player.equiped_accessory1 = _item;
		}
		else if(obj_Player.equiped_accessory2 == global.item_list.none && obj_Player.equiped_accessory1 != global.item_list.none && _item == global.item_list.none)
		{
			array_delete(obj_Item_Manager.inventory_accessory, _position, 1);
			array_insert(obj_Item_Manager.inventory_accessory, 1,obj_Player.equiped_accessory1);
			obj_Player.equiped_accessory1 = _item;
		}
		else if(obj_Player.equiped_accessory2 == global.item_list.none && obj_Player.equiped_accessory1 != global.item_list.none && _item != global.item_list.none)
		{
			array_delete(obj_Item_Manager.inventory_accessory, _position, 1);
			array_insert(obj_Item_Manager.inventory_accessory, 1,obj_Player.equiped_accessory1);
			obj_Player.equiped_accessory1 = _item;
		}
		else if(obj_Player.equiped_accessory2 != global.item_list.none && obj_Player.equiped_accessory1 == global.item_list.none && _item == global.item_list.none)
		{
			
		}
		else if(obj_Player.equiped_accessory2 != global.item_list.none && obj_Player.equiped_accessory1 == global.item_list.none && _item != global.item_list.none)
		{
			array_delete(obj_Item_Manager.inventory_accessory, _position, 1);
			obj_Player.equiped_accessory1 = _item;
		}
		else if(obj_Player.equiped_accessory2 != global.item_list.none && obj_Player.equiped_accessory1 != global.item_list.none && _item == global.item_list.none)
		{
			array_insert(obj_Item_Manager.inventory_accessory, 1,obj_Player.equiped_accessory1);
			obj_Player.equiped_accessory1 = _item;
		}
		else if(obj_Player.equiped_accessory2 != global.item_list.none && obj_Player.equiped_accessory1 != global.item_list.none && _item != global.item_list.none)
		{
			array_delete(obj_Item_Manager.inventory_accessory, _position, 1);
			array_insert(obj_Item_Manager.inventory_accessory, 1,obj_Player.equiped_accessory1);
			obj_Player.equiped_accessory1 = _item;
		}
	}
}
function equip_accessory2(_item, _position)
{
	//array_delete(obj_Item_Manager.inventory_accessory, _position, 1);
	//array_insert(obj_Item_Manager.inventory_accessory, 0, global.item_list.none);
	//obj_Player.equiped_accessory1 = _item;
	//array_push(obj_Item_Manager.inventory_accessory, obj_Player.equiped_accessory1);
	if!(_item == global.item_list.none && obj_Player.equiped_accessory2 == global.item_list.none)
	{
		if(obj_Player.equiped_accessory1 == global.item_list.none && obj_Player.equiped_accessory2 == global.item_list.none && _item == global.item_list.none)
		{
			
		}
		else if(obj_Player.equiped_accessory1 == global.item_list.none && obj_Player.equiped_accessory2 == global.item_list.none && _item != global.item_list.none)
		{
			array_delete(obj_Item_Manager.inventory_accessory, _position, 1);
			array_insert(obj_Item_Manager.inventory_accessory, 0, global.item_list.none);
			obj_Player.equiped_accessory2 = _item;
		}
		else if(obj_Player.equiped_accessory1 == global.item_list.none && obj_Player.equiped_accessory2 != global.item_list.none && _item == global.item_list.none)
		{
			array_delete(obj_Item_Manager.inventory_accessory, _position, 1);
			array_insert(obj_Item_Manager.inventory_accessory, 1,obj_Player.equiped_accessory2);
			obj_Player.equiped_accessory2 = _item;
		}
		else if(obj_Player.equiped_accessory1 == global.item_list.none && obj_Player.equiped_accessory2 != global.item_list.none && _item != global.item_list.none)
		{
			array_delete(obj_Item_Manager.inventory_accessory, _position, 1);
			array_insert(obj_Item_Manager.inventory_accessory, 1,obj_Player.equiped_accessory2);
			obj_Player.equiped_accessory2 = _item;
		}
		else if(obj_Player.equiped_accessory1 != global.item_list.none && obj_Player.equiped_accessory2 == global.item_list.none && _item == global.item_list.none)
		{
			
		}
		else if(obj_Player.equiped_accessory1 != global.item_list.none && obj_Player.equiped_accessory2 == global.item_list.none && _item != global.item_list.none)
		{
			array_delete(obj_Item_Manager.inventory_accessory, _position, 1);
			obj_Player.equiped_accessory2 = _item;
		}
		else if(obj_Player.equiped_accessory1 != global.item_list.none && obj_Player.equiped_accessory2 != global.item_list.none && _item == global.item_list.none)
		{
			array_insert(obj_Item_Manager.inventory_accessory, 1,obj_Player.equiped_accessory2);
			obj_Player.equiped_accessory2 = _item;
		}
		else if(obj_Player.equiped_accessory1 != global.item_list.none && obj_Player.equiped_accessory2 != global.item_list.none && _item != global.item_list.none)
		{
			array_delete(obj_Item_Manager.inventory_accessory, _position, 1);
			array_insert(obj_Item_Manager.inventory_accessory, 1,obj_Player.equiped_accessory2);
			obj_Player.equiped_accessory2 = _item;
		}
	}
}
#endregion
