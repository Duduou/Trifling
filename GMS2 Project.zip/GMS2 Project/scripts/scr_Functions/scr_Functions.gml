// Script assets have changed for v2.3.0 see
// https://help.yoyogames.com/hc/en-us/articles/360005277377 for more information
function scr_functions()
{

}
#region SCREENSHAKE
function screenshake(_shake)
{
	var shake = instance_create_layer(0, 0, "player", obj_Screenshake);
	shake.shake = _shake;
}
#endregion
#region DRAW OUTILINE
function draw_text_outlined(x, y, outline_color, string_color, string, outiline, scalex, scaley) 
{
var xx,yy;  
xx = argument[0];  
yy = argument[1];  
    
draw_set_color(argument[2]);  
draw_text_transformed(xx+argument[5], yy+argument[5], argument[4], scalex * global._scalexx/4, scaley * global._scaleyy/4, 0);  
draw_text_transformed(xx-argument[5], yy-argument[5], argument[4], scalex * global._scalexx/4, scaley * global._scaleyy/4, 0);  
draw_text_transformed(xx,   yy+argument[5], argument[4], scalex * global._scalexx/4, scaley * global._scaleyy/4, 0);  
draw_text_transformed(xx+argument[5],   yy, argument[4], scalex * global._scalexx/4, scaley * global._scaleyy/4, 0);  
draw_text_transformed(xx,   yy-argument[5], argument[4], scalex * global._scalexx/4, scaley * global._scaleyy/4, 0);  
draw_text_transformed(xx-argument[5],   yy, argument[4], scalex * global._scalexx/4, scaley * global._scaleyy/4, 0);  
draw_text_transformed(xx-argument[5], yy+argument[5], argument[4], scalex * global._scalexx/4, scaley * global._scaleyy/4, 0);  
draw_text_transformed(xx+argument[5], yy-argument[5], argument[4], scalex * global._scalexx/4, scaley * global._scaleyy/4, 0);  
   
draw_set_color(argument[3]);  
draw_text_transformed(xx, yy, argument[4], scalex * global._scalexx/4, scaley * global._scaleyy/4, 0);
}
#endregion