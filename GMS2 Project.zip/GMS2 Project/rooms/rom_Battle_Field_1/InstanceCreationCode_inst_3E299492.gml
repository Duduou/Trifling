target_room = rom_Player_House
interact = true;
target_x = 68;
target_y = 56;