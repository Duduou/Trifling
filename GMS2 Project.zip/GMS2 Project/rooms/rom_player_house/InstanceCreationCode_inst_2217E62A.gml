target_room = rom_Battle_Field_1
interact = true;
target_x = 58;
target_y = 121;