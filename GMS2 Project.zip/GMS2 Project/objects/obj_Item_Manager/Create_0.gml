depth = -9999;

inventory_item = array_create(0);
inventory_key_item = array_create(0);
inventory_weapon = array_create(0);
inventory_armor = array_create(0);
inventory_accessory = array_create(0);

function create_item(_portait2,_slot, _object, _price, _nick, _mini, _portait, _drop, _description, _can_sell, _stack, _use, _stats, _skin1, _skin2) constructor
{
	portait_ = _portait2;
	slot = _slot
	object = _object;
	price = _price;
	nick = _nick;
	mini = _mini;
	portait = _portait;
	drop = _drop;
	description = _description;
	can_sell = _can_sell;
	stack = _stack
	use = _use;
	stats = _stats;
	skin1 = _skin1;
	skin2 = _skin2;
}
function stats_item(_type, _health, _energy, _damage, _defense, _speed,_physical, _fire, _water, _thunder, _nature, _physical_resistence, _fire_resistence, _water_resistence, _thunder_resistence, _nature_resistence) constructor
{
	type_ = _type;
	health_ = _health;
	energy = _energy; 
	damage =_damage; 
	defense = _defense; 
	speed_ = _speed;
	physical = _physical;
	fire = _fire;
	water = _water;
	thunder = _thunder;
	nature = _nature;
	physical_resistence = _physical_resistence;
	fire_resistence = _fire_resistence;
	water_resistence = _water_resistence;
	thunder_resistence = _thunder_resistence;
	nature_resistence = _nature_resistence;
}
function skin1_item(_idle, _walk, _attack, _crouch, _crouchattack, _death, _hurt, _jump, _jumpattack, _roll, _wallslide) constructor
{
	idle1 = _idle;
	walk1 = _walk;
	attack1 = _attack;
	crouch1 = _crouch;
	crouchattack1 = _crouchattack;
	death1 = _death;
	hurt1 = _hurt;
	jump1 = _jump;
	jumpattack1 = _jumpattack;
	roll1 = _roll;
	wallslide1 = _wallslide;
}
function skin2_item(_idle, _walk, _attack, _crouch, _crouchattack, _death, _hurt, _jump, _jumpattack, _roll, _wallslide) constructor
{
	idle2 = _idle;
	walk2 = _walk;
	attack2 = _attack;
	crouch2 = _crouch;
	crouchattack2 = _crouchattack;
	death2 = _death;
	hurt2 = _hurt;
	jump2 = _jump;
	jumpattack2 = _jumpattack;
	roll2 = _roll;
	wallslide2 = _wallslide;
}
global.item_list =
{
	#region EMPTY
	none:
	new create_item(
	spr_Default_Portait,	//portait_
	noone,	//slot
	noone,	//object
	noone,	//price
	"EMPTY",	//nick
	spr_None_Mini,	//mini
	spr_None_Portait,	//portait
	noone,	//drop
	"JUST A LOT OF NOTHING",	//decription
	false,		//can_sell
	0,	//stack
	noone,	//use
	new stats_item(
		0,	//type_
		0,	//health_
		0,	//energy
		0,	//damage = all damages
		0,	//defense = all defenses
		0,	//speed_
		0,	//physical
		0,	//fire
		0,	//water
		0,	//thunder
		0,	//nature
		0,	//physical_resistence
		0,	//fire_resistence
		0,	//water_resistence
		0,	//thunder_resistence
		0	//nature_resistence
		),
	new skin1_item
		(
			spr_Default_Idle_1,	//idle1
			spr_Default_Walk_1,	//walk1
			spr_Default_Attack_1,	//attack1
			spr_Default_Crouch_1,	//crouch1
			spr_Default_Crouch_Attack_1,	//crouchattack1
			spr_Default_Death_1,	//death1
			spr_Default_Hurt_1,	//hurt1
			spr_Default_Jump_1,	//jump1
			spr_Default_Jump_Attack_1,	//jumpattack1
			spr_Default_Roll_1,	//roll1
			spr_Default_Wall_Slide_1, //wallslide1
		),
	new skin2_item
		(
			spr_Default_Idle_2,	//idle2
			spr_Default_Walk_2,	//walk2
			spr_Default_Attack_2,	//attack2
			spr_Default_Crouch_2,	//crouch2
			spr_Default_Crouch_Attack_2,	//crouchattack2
			spr_Default_Death_2,	//death2
			spr_Default_Hurt_2,	//hurt2
			spr_Default_Jump_2,	//jump2
			spr_Default_Jump_Attack_2,	//jumpattack2
			spr_Default_Roll_2,	//roll2
			spr_Default_Wall_Slide_2, //wallslide2
		)
	),
	#endregion
	#region ITEMS
	min_life_potion:
	new create_item(
	noone, //portait_
	inventory_item,
	noone,
	2,
	"MIN LIFE POTION",
	spr_Life_Potion_Lv1_Mini,
	spr_Life_Potion_Lv1_Portait,
	obj_Min_Life_Potion_Drop,
	"A SMALL HEALTH POTION, THE FORMULA DOESN'T SEEM VERY PURE BUT IT SHOULD WORK, USE IT TO RESTORE YOUR HEALTH IN 10 ",
	true,
	1,
	function()
	{
		obj_Player.life += 10;
	},
	noone,
	noone,
	noone,
	),
	#endregion
	#region WEAPONS KNIGHT
	#region EMPTY
		empty: 
		new create_item(
			noone,	//portait_
			inventory_weapon,
			obj_Empty,
			0,
			"EMPTY",
			spr_Empty_Mini,
			spr_Empty_Portait,
			noone,
			"THE CLASSIC AND RELIABLE FISTS, NOTHING BETTER THAN YOUR OWN FISTS TO HIT THE ENEMY IN FRONT OF YOU, BUT IT DOESN'T SEEM TO BE VERY EFFICIENT... AND IT'S A LITTLE RISKY... MAYBE YOU SHOULD LOOK FOR A WEAPON",
			false,
			1,
			noone,
			new stats_item(
			1,	//type_
			0,	//health_
			0,	//energy
			1,	//damage = all damages
			0,	//defense = all defenses
			10,	//speed_
			1,	//physical
			0,	//fire
			0,	//water
			0,	//thunder
			0,	//nature
			0,	//physical_resistence
			0,	//fire_resistence
			0,	//water_resistence
			0,	//thunder_resistence
			0	//nature_resistence
			),
			new skin1_item
			(
				spr_Empty,	//idle1
				spr_Empty,	//walk1
				spr_Empty,	//attack1
				spr_Empty,	//crouch1
				spr_Empty,	//crouchattack1
				spr_Empty,	//death1
				spr_Empty,	//hurt1
				spr_Empty,	//jump1
				spr_Empty,	//jumpattack1
				spr_Empty,	//roll1
				spr_Empty,	//wallslide1	
			),
			noone
		),
	#endregion
	#region STICK
		stick: new create_item
		(
			noone,	//portait_
			inventory_weapon,
			obj_Stick,
			1,
			"STICK",
			spr_Stick_Mini,
			spr_Stick_Portait,
			obj_Stick_Drop,
			"JUST AN ORDINARY BRANCH FOUND ON THE GROUND, HOWEVER WITH A NICE SHAPE, IS BETTER THAN HITTING IT WITH YOUR HANDS, RIGHT?",
			true,
			1,
			noone,
			new stats_item
			(
			1,	//type_
			0,	//health_
			0,	//energy
			2,	//damage = all damages
			0,	//defense = all defenses
			3,	//speed
			2,	//physical
			0,	//fire
			0,	//water
			0,	//thunder
			0,	//nature
			0,	//physical_resistence
			0,	//fire_resistence
			0,	//water_resistence
			0,	//thunder_resistence
			0	//nature_resistence
			),
			new skin1_item
			(
				spr_Stick_Idle,	//idle1
				spr_Stick_Walk,	//walk1
				spr_Stick,	//attack1
				spr_Stick_Crouch,	//crouch1
				spr_Stick,	//crouchattack1
				spr_Stick_Death,	//death1
				spr_Stick_Hurt,	//hurt1
				spr_Stick_Jump,	//jump1
				spr_Stick,	//jumpattack1
				spr_Stick_Roll,	//roll1
				spr_Stick_Wall_Slide,	//wallslide1
			),
			noone
		),
	#endregion
	#region CLUB
		club: new create_item
		(
			noone,	//portait_
			inventory_weapon,
			obj_Club,
			1,
			"CLUB",
			spr_Club_Mini,
			spr_Club_Portait,
			obj_Club_Drop,
			"JUST AN ORDINARY BRANCH FOUND ON THE GROUND, HOWEVER WITH A NICE SHAPE, IS BETTER THAN HITTING IT WITH YOUR HANDS, RIGHT?",
			true,
			1,
			noone,
			new stats_item
			(
			2,	//type_
			0,	//health_
			0,	//energy
			4,	//damage = all damages
			0,	//defense = all defenses
			1,	//speed
			4,	//physical
			0,	//fire
			0,	//water
			0,	//thunder
			0,	//nature
			0,	//physical_resistence
			0,	//fire_resistence
			0,	//water_resistence
			0,	//thunder_resistence
			0	//nature_resistence
			),
			new skin1_item
			(
				spr_Club_Idle,	//idle1
				spr_Club_Walk,	//walk1
				spr_Club_Attack,	//attack1
				spr_Club_Crouch,	//crouch1
				spr_Club_Attack,	//crouchattack1
				spr_Club_Death,	//death1
				spr_Club_Hurt,	//hurt1
				spr_Club_Jump,	//jump1
				spr_Club_Attack,	//jumpattack1
				spr_Club_Roll,	//roll1
				spr_Club_Wall_Slide,	//wallslide1
			),
			noone
		),
	#endregion
	#endregion
	#region ARMORS KNIGHT
	cardboard_armor: 
	new create_item(
		spr_Knight_Portait,	//portait_
		inventory_armor,
		noone,
		1,
		"CARDBOARD ARMOR",
		spr_Cardboard_Armor_Mini,
		spr_Cardboard_Armor_Portait,
		noone,
		"IS THIS ARMOR MADE OF CARDBOARD? WOW...DID YOU HAVE ANY BETTER IDEA? THAT'S WELL THEN, BUT IT WON'T PROTECT YOU FROM WHAT'S NEXT ",
		true,
		1,
		noone,
		new stats_item(
		0,	//type_
		0,	//health_
		0,	//energy
		0,	//damage = all damages
		0.5,//defense = all defenses
		0,	//speed_
		0,	//physical
		0,	//fire
		0,	//water
		0,	//thunder
		0,	//nature
		0.5,//physical_resistence
		0,	//fire_resistence
		0,	//water_resistence
		0,	//thunder_resistence
		0	//nature_resistence
		),
		new skin1_item
		(
			spr_Knight_Idle_1,	//idle1
			spr_Knight_Walk_1,	//walk1
			spr_Knight_Attack_1,	//attack1
			spr_Knight_Crouch_1,	//crouch1
			spr_Knight_Crouch_Attack_1,	//crouchattack1
			spr_Knight_Death_1,	//death1
			spr_Knight_Hurt_1,	//hurt1
			spr_Knight_Jump_1,	//jump1
			spr_Knight_Jump_Attack_1,	//jumpattack1
			spr_Knight_Roll_1,	//roll1
			spr_Knight_Wall_Slide_1,	//wallslide1
		),
		new skin2_item
		(
			spr_Knight_Idle_2,	//idle2
			spr_Knight_Walk_2,	//walk2
			spr_Knight_Attack_2,	//attack2
			spr_Knight_Crouch_2,	//crouch2
			spr_Knight_Crouch_Attack_2,	//crouchattack2
			spr_Knight_Death_2,	//death2
			spr_Knight_Hurt_2,	//hurt2
			spr_Knight_Jump_2,	//jump2
			spr_Knight_Jump_Attack_2,	//jumpattack2
			spr_Knight_Roll_2,	//roll2
			spr_Knight_Wall_Slide_2,	//wallslide2
		)
	),
	#endregion
	#region ACCESSORIES
	ring_of_life: 
	new create_item(
		noone,	//portait
		inventory_accessory,
		noone,
		3,
		"RING OF LIFE",
		spr_Ring_Of_Life_Mini,
		spr_Ring_Of_Life_Portait,
		obj_Ring_Of_Life_Drop,
		"THE RING HAS A LIGHT RED GLOSS, WHEN HOLDING IT YOU FEEL EASIER TO BREATHE",
		true,
		1,
		noone,
		new stats_item(
		0,	//type_
		5,	//health_
		0,	//energy
		0,	//damage = all damages
		0,	//defense = all defenses
		0,	//speed_
		0,	//physical
		0,	//fire
		0,	//water
		0,	//thunder
		0,	//nature
		0,	//physical_resistence
		0,	//fire_resistence
		0,	//water_resistence
		0,	//thunder_resistence
		0	//nature_resistence
		),
		noone,
		noone
	),
	ring_of_speed: 
	new create_item(
		noone,	//portait_
		inventory_accessory,
		noone,
		3,
		"RING OF SPEED",
		spr_Ring_Of_Speed_Mini,
		spr_Ring_Of_Speed_Portait,
		obj_Ring_Of_Speed_Drop,
		"DO YOU FEEL THAT THIS RING IS EXTREMELY LIGHT, SO LIGHT THAT WHEN PUTTING IT ON YOUR FINGER YOU FEEL CONSIDERABLY LIGHTER",
		true,
		1,
		noone,
		new stats_item(
		0,	//type_
		0,	//health_
		0,	//energy
		0,	//damage = all damages
		0,	//defense = all defenses
		1,	//speed_
		0,	//physical
		0,	//fire
		0,	//water
		0,	//thunder
		0,	//nature
		0,	//physical_resistence
		0,	//fire_resistence
		0,	//water_resistence
		0,	//thunder_resistence
		0	//nature_resistence
		),
		noone,
		noone
	),
	#endregion
}