if!(obj_Menu.reset_accessory || obj_Menu.reset_armor || obj_Menu.reset_weapon || obj_Menu.reset_item)
{
	for(var i = 0; i < array_length(inventory_item); i++)
	{
		obj_Menu.option[6, i] = inventory_item[i];
	}
	for(var i = 0; i < array_length(inventory_key_item); i++)
	{
		obj_Menu.option[7, i] = inventory_key_item[i];
	}
	for(var i = 0; i < array_length(inventory_weapon); i++)
	{
		obj_Menu.option[8, i] = inventory_weapon[i];
	}
	for(var i = 0; i < array_length(inventory_armor); i++)
	{
		obj_Menu.option[9, i] = inventory_armor[i];
	}
	for(var i = 0; i < array_length(inventory_accessory); i++)
	{
		obj_Menu.option[10, i] = inventory_accessory[i];
	}
}
