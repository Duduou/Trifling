#region BARS
if(instance_exists(obj_Player) && room_get_name(room) != "rom_Main_Menu")
{
	draw_sprite_ext(spr_Health_Bar, 0, (11 * bar_scale)  * global._scalexx/4, (6 * bar_scale)  * global._scaleyy/4, bar_xscale  * global._scalexx/4, bar_scale * global._scaleyy/4, 0, c_white, 1);
	draw_sprite_ext(spr_Health_Bar_1, 0, (11 * bar_scale) * global._scalexx/4, (6 * bar_scale) * global._scaleyy/4, bar_max_xscale  * global._scalexx/4, bar_scale  * global._scaleyy/4, 0, c_white, 1);
	draw_sprite_ext(spr_Health_Bar_2, 0, ((7 * bar_scale) + (bar_max_xscale * 5)) * global._scalexx/4, (6 * bar_scale) * global._scaleyy/4, bar_scale * global._scalexx/4, bar_scale * global._scalexx/4, 0, c_white, 1);
	draw_sprite_ext(sprite_portait, 0, (1 * bar_scale) * global._scalexx/4, (7 * bar_scale) * global._scaleyy/4, bar_scale * global._scalexx/4, bar_scale * global._scaleyy/4, 0, c_white, 1);
	if(bar_xscale > bar_scale)
	{
		var bar_line = floor(bar_xscale / bar_scale) + 1;
		for(var i = 1; i < bar_line; i++)
		{
			draw_sprite_ext(spr_Health_Bar_Line, 0, (5 * (bar_scale * i+8)) * global._scalexx/4, (6 * bar_scale) * global._scaleyy/4, bar_scale * global._scalexx/4, bar_scale * global._scaleyy/4, 0, c_white, 1);
		}
	}
	draw_sprite_ext(spr_Fury_Bar, 0, (11 * bar_scale) * global._scalexx/4, (10 * bar_scale) * global._scaleyy/4, bar2_xscale * global._scalexx/4, bar_scale * global._scaleyy/4, 0, c_white, 1);
	draw_sprite_ext(spr_Fury_Bar_1, 0, (11 * bar_scale) * global._scalexx/4, (10 * bar_scale) * global._scaleyy/4, bar2_max_xscale * global._scalexx/4, bar_scale * global._scaleyy/4, 0, c_white, 1);
	draw_sprite_ext(spr_Fury_Bar_2, 0, (( 9 * bar_scale) + (bar2_max_xscale * 3)) * global._scalexx/4, (10 * bar_scale) * global._scaleyy/4, bar_scale * global._scalexx/4, bar_scale * global._scaleyy/4, 0, c_white, 1);
	if(bar2_xscale > bar_scale)
	{
		var bar2_line = floor(bar2_xscale / bar_scale) + 1;
		for(var i = 1; i < bar2_line; i++)
		{
			draw_sprite_ext(spr_Fury_Bar_Line, 0, (3 * (bar_scale * i+18)) * global._scalexx/4, (10 * bar_scale) * global._scaleyy/4, bar_scale * global._scalexx/4, bar_scale * global._scaleyy/4, 0, c_white, 1);
		}
	}
}
#endregion
if(room_get_name(room) == "rom_Main_Menu")
{
	if(instance_exists(obj_Player))
	{
		instance_deactivate_layer("Player");
	}
	if(!audio_is_playing(snd_Main_Menu_Music) && !audio_is_playing(snd_Main_Menu_Music_Loop))
	{
		audio_play_sound(snd_Main_Menu_Music_Loop,0,true);
	}
}
else
{
	audio_stop_all();
	draw_set_alpha(1);
}
