global._scalexx = display_get_gui_width()/camera_get_view_width(0) * 6;
global._scaleyy = display_get_gui_height()/camera_get_view_height(0) * 6;
if(instance_exists(obj_Player) && room_get_name(room) != "rom_Main_Menu")
{
	bar_max_xscale = lerp(bar_max_xscale, obj_Player.max_life * 0.5, 0.3);
	bar_xscale = (lerp(bar_xscale, obj_Player.life * 0.5, 0.3));
	bar2_max_xscale = lerp(bar2_max_xscale, obj_Player.max_energy * 1.5, 0.3);
	bar2_xscale = (lerp(bar2_xscale, obj_Player.energy * 1.5, 0.3));
}
if(room_width < camera_width && room_height < camera_height)
{
	camera_set_view_size(view_camera[0], room_width, room_height);
}
else if(room_width < camera_width)
{
	camera_set_view_size(view_camera[0], room_width, camera_get_view_width(view_camera[0]));
}
else if(room_height < camera_height)
{
	camera_set_view_size(view_camera[0], camera_get_view_height(view_camera[0]), room_height);
}
else
{
	camera_set_view_size(view_camera[0], camera_width, camera_height);
}
if(keyboard_check_pressed(vk_f11)){full_screen = !full_screen}
window_set_fullscreen(full_screen);
if(keyboard_check_pressed(ord("R")))
{
	game_restart();
}
