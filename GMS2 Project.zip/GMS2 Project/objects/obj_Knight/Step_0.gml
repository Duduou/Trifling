#region CONTROLS
if!(obj_Menu.menu_level == 6 || obj_Menu.menu_level == 7 || obj_Menu.menu_level == 8 || obj_Menu.menu_level == 9 || obj_Menu.menu_level == 10 || obj_Menu.menu_level == 11 || obj_Menu.menu_level == 12)
{
	if(state != "roll")
	{
		key_right = keyboard_check(ord("D")) || keyboard_check(vk_right);
		key_left = keyboard_check(ord("A")) || keyboard_check(vk_left);
	}
	key_roll = keyboard_check_pressed(ord("L"));
}
key_menu = keyboard_check_pressed(ord("I"));
key_jump = keyboard_check_pressed(vk_space);
if(key_menu)
{
	show_menu = !show_menu;
	if(!show_menu)
	{
		obj_Menu.menu_level = 0;	
	}
}
key_jump_released = keyboard_check_released(vk_space);
if (can_attack && !show_menu)
{
	key_attack = keyboard_check_pressed(ord("J")) || keyboard_check(vk_shift);
}
if(!can_fall)
{
	vspd = 0;	
}
if(!show_menu)
{
	key_up = keyboard_check_pressed(ord("W"));
	key_down = keyboard_check(ord("S")) || keyboard_check(vk_down);
}
#endregion
#region STATS
atk_physical = equiped_weapon.stats.physical + equiped_armor.stats.physical + equiped_accessory1.stats.physical + equiped_accessory2.stats.physical;
atk_fire = equiped_weapon.stats.fire + equiped_armor.stats.fire + equiped_accessory1.stats.fire + equiped_accessory2.stats.fire;
atk_water = equiped_weapon.stats.water + equiped_armor.stats.water + equiped_accessory1.stats.water + equiped_accessory2.stats.water;
atk_thunder = equiped_weapon.stats.thunder + equiped_armor.stats.thunder + equiped_accessory1.stats.thunder + equiped_accessory2.stats.thunder;
atk_nature = equiped_weapon.stats.nature + equiped_armor.stats.nature + equiped_accessory1.stats.nature + equiped_accessory2.stats.nature;
def_physical = equiped_weapon.stats.physical_resistence + equiped_armor.stats.physical_resistence + equiped_accessory1.stats.physical_resistence + equiped_accessory2.stats.physical_resistence;
def_fire = equiped_weapon.stats.fire_resistence + equiped_armor.stats.fire_resistence + equiped_accessory1.stats.fire_resistence + equiped_accessory2.stats.fire_resistence;
def_water = equiped_weapon.stats.water_resistence + equiped_armor.stats.water_resistence + equiped_accessory1.stats.water_resistence + equiped_accessory2.stats.water_resistence;
def_thunder = equiped_weapon.stats.thunder_resistence + equiped_armor.stats.thunder_resistence + equiped_accessory1.stats.thunder_resistence + equiped_accessory2.stats.thunder_resistence;
def_nature = equiped_weapon.stats.nature_resistence + equiped_armor.stats.nature_resistence + equiped_accessory1.stats.nature_resistence + equiped_accessory2.stats.nature_resistence;
max_life = base_life + equiped_armor.stats.health_ + equiped_weapon.stats.health_ + equiped_accessory1.stats.health_ + equiped_accessory2.stats.health_;
max_energy = base_energy + equiped_armor.stats.energy + equiped_weapon.stats.energy + equiped_accessory1.stats.energy + equiped_accessory2.stats.energy;
dmg = base_damage + atk_physical + atk_fire + atk_water + atk_thunder + atk_nature;
defense = base_defense + def_physical + def_fire + def_water + def_thunder + def_nature;
speed_ = base_speed + equiped_armor.stats.speed_ + equiped_weapon.stats.speed_ + equiped_accessory1.stats.speed_ + equiped_accessory2.stats.speed_;
if(life > max_life)
{
	life = max_life;	
}
if(life < 0)
{
	life = 0;	
}
if(energy > max_energy)
{
	energy = max_energy;	
}
if(energy < 0)
{
	energy = 0;	
}
#endregion
#region COLLISION AND MOVIMENT
var _hspd = sign(hspd);
var _vspd = sign(vspd);
ground = place_meeting(x-sign(image_xscale), y + 1, obj_Wall);
if(ground)
{
	y =  floor(y);	
}
var dir_jump = false;
if(place_meeting(x - sign(image_xscale), y, obj_Wall))
{
	can_jump = false
	x += sign(image_xscale);
}
else if(place_meeting(x + sign(image_xscale), bbox_bottom, obj_Wall))
{
	can_jump = true;	
}
if(place_meeting(x - sign(image_xscale), y, obj_Wall))
{
	ground = place_meeting(x + sign(image_xscale), y + 1, obj_Wall);
	can_jump = false;
	dir_jump = true;
}
else
{
	place_meeting(x-sign(image_xscale), y + 1, obj_Wall);
	dir_jump = false;	
}
if !(key_down && key_jump)
{
	if(instance_place(x, y+2, obj_Plataform))
	{
		plataform_ = instance_place(x, y+2, obj_Plataform).bbox_top
	}
	else
	{
		plataform_ = -1000000000000000000;	
	}
	if(!instance_place(bbox_right, y+2, obj_Plataform) && bbox_bottom >= plataform - 1|| !instance_place(bbox_left, y+2, obj_Plataform) && bbox_bottom >= plataform - 1)
	{
		plataform = -1000000000000000000;
	}
	if(plataform_ != -1000000000000000000 && plataform != plataform_)
	{
		plataform = plataform_;
	}
	if plataform == bbox_bottom && _vspd > 0
	{
		ground = true;
	}
	if(plataform)
	{
		can_jump = true;
	}
}
else if(plataform == bbox_bottom)
{
	can_move = true;
	y += 0.0001;
	state = "jump";
	image_index = 0;
}
if(state != "roll")
{
	if(state == "idle" || state == "walk")
	{
		hspd = key_right - key_left;
	}
	else if((key_right - key_left) < hspd)
	{
		hspd -= 0.25;
	}
	else if((key_right - key_left) > hspd)
	{
		hspd += 0.25;
	}
}
if _hspd != 0 && can_turn = true
{
image_xscale = _hspd;
}
if hspd != 0 {spd = lerp(spd,spd2,0.3)}
if hspd == 0 {spd = 0}
for(var i = 0; i < abs(hspd); i++)
{
	if place_meeting(x+(hspd*2), y, obj_Wall)
	{
		if place_meeting(x, y, obj_Wall)
		{
			hspd = 0;
			break;
		}
	}
	if can_move == true
	{
		x += _hspd * spd;
	}
}
if(!ground && !jumping)
{
	timer_jump++;
}
else
{
	timer_jump = 0;	
}
if(!ground && vspd > 0 && position_meeting(x + image_xscale * 2, y, obj_Wall))
{
	if(wall == 0)
	{
		if place_meeting(x + 1,y,obj_Wall)
		{
			wall = 1;
			image_xscale = image_xscale * wall;
		}
		else if place_meeting(x - 1,y,obj_Wall)
		{
			wall = -1;
			image_xscale = image_xscale * wall;
		}
	}
	if(attack != noone)
	{
		instance_destroy(attack);
		image_xscale = image_xscale * -wall;
		can_turn = true;
	}
	state = "wall slide"
}
else
{
	wall = 0;
}
for(var i = 0; i < abs(vspd); i++)
{
	if(dir_jump = true)
	{
		if place_meeting(x + sign(image_xscale), y+_vspd, obj_Wall)
		{
			vspd = 0;
			break;
		}
	}
	else
	{
		if place_meeting(x-sign(image_xscale), y+_vspd, obj_Wall)
		{
			vspd = 0;
			break;
		}
	}
	if _vspd > 0 && plataform == bbox_bottom
	{
		vspd = 0;
		ground = true;
		break;
	}
	if(state != "wall slide")
	{
		y += _vspd;
	}
	else
	{
		y += _vspd * mass;
	}
	if(ground)
	{
		y = floor(y);
	}
}
if !ground 
{
	if(vspd <= max_vspd)
	{
		vspd += GRAV * mass;
	}
}
if(ground || timer_jump > 0 && timer_jump < 6 || state == "wall slide")
{
	if key_jump && state != "death" && can_jump
	{
		vspd = -jump_pow;
		stop_jump = true;
		jumping = true;
	}
}
if(_vspd < 0 && key_jump_released && stop_jump)
{
	vspd = lerp(vspd, 0, 0.6);
	stop_jump = false;
}
if(jumping = true && ground && vspd >= 0)
{
	jumping = false;	
}
#endregion
#region STATE MACHINE
switch(state)
{
	case "idle" :
	{
		image_speed = 1;
		sprite_index = sprite_idle
		if(abs(hspd) > 0.3 && can_move = true && !place_meeting(x+_hspd*2, y, obj_Wall))
		{
			state = "walk";
			image_index = 0;
		}
		if(key_jump && ground)
		{
			state = "jump";
			image_index = 0; 
		}
		if(!ground)
		{
			state = "jump";
			image_index = 3;
		}
		if(key_down && ground)
		{
			state = "crouch";
			image_index = 0;
		}
		if(key_attack)
		{
			if(cooldown <= 0)
			{
				state = "attack";
				image_index = 0;
			}
		}
		if(!ground && key_attack)
		{
			if(cooldown <= 0)
			{
				state = "jump attack";
				image_index = 0;
			}
		}
		if(ground && key_roll && roll_cooldown >= 30)
		{
			rolled = false;
			state = "roll";
			image_index = 0
		}
		break;	
	}
	case "walk" :
	{
		image_speed = 1;
		sprite_index = sprite_walk;
		if(hspd = 0)
		{
			state = "idle";
			image_index = 0;
		}
		if(key_jump && ground)
		{
			state = "jump";
			image_index = 0;
		}
		if(!ground)
		{
			state = "jump";
			image_index = 3;
		}
		if(key_down && ground)
		{
			state = "crouch";
			image_index = 0;
		}
		if(key_attack)
		{
			if(cooldown <= 0)
			{
				state = "attack";
				image_index = 0;
			}
		}
		if(!ground && key_attack)
		{
			if(cooldown <= 0)
			{
				state = "jump attack";
				image_index = 0;
			}
		}
		if(ground && key_roll && roll_cooldown >= 30)
		{
			rolled = false;
			state = "roll";
			image_index = 0
		}
		break;	
	}
	case "jump":
	{
		can_move = true;
		image_speed = 1;
		sprite_index = sprite_jump;
		if (image_speed > 0)
		{
			 if (image_index >= image_number - 1)
			 {
				image_speed = 0; 
			 }
		}
		if(image_speed == 0 || ground || key_attack)
		{
			can_move = true;
			if(key_down && ground)
			{
				state = "crouch";
				image_index = 0;
			}
			if((hspd = 0) && ground)
			{
				state = "idle";
				image_index = 0;
			}
			if(abs(hspd) > 0.3 && can_move = true && !place_meeting(x+_hspd*2, y, obj_Wall) && ground)
			{
				state = "walk";
				image_index = 0;
			}
			if(key_roll && roll_cooldown >= 30)
			{
				rolled = false;
				state = "roll";
				image_index = 0
			}
		}
		if(key_attack)
			{
				can_move = true;
				if(cooldown <= 0)
				{
					state = "jump attack";
					image_index = 0;
				}
			}
		break;
	}
	case "crouch":
	{
		can_move = false;
		image_speed = 1;
		sprite_index = sprite_crouch;
		if (image_speed > 0)
		{
			 if (image_index >= image_number - 1)
			 {
				image_speed = 0;	 
			 }
		}
		if !key_down
		{
			image_speed = -1;
			if (image_index < 1)
			{
				can_move = true;
				if(hspd = 0)
				{
					state = "idle";
					image_index = 0;
				}
				if(abs(hspd) > 0.1 && can_move = true)
				{
					state = "walk";
					image_index = 0;
				}
			}
		}
		if(key_attack && key_down)
		{
			if(cooldown <= 0)
			{
			state = "crouch attack";
			image_index = image_number - 1;
			}
		}
		if(key_roll && roll_cooldown >= 30)
		{
			rolled = false;
			state = "roll";
			image_index = image_number - 2
		}
		if(key_jump)
		{
			can_move = true;
			can_jump = true;
			state = "jump";
			image_index = 0;
		}
		break;
	}
	case "roll":
	{
		can_move = false;
		can_jump = false;
		invencible = true;
		image_speed = 1;
		sprite_index = sprite_roll;
		if (image_speed > 0)
		{
				if (image_index >= image_number - 1)
				{
				image_speed = 0;	 
				}
		}
		timer_roll++;
		if(timer_roll <= 23.333 && !rolled)
		{
			if!(place_meeting(x+1,y - 1,obj_Wall) || place_meeting(x-1,y - 1,obj_Wall))
			{
				x += image_xscale * spd2 * 1.5	
			}
			rolling = true;
		}
		if(timer_roll > 23.333 && !rolled)
		{
			rolling = false;
			roll_cooldown = 0;
		}
		if image_speed == 0 && !rolling
		{
			invencible = false;
			can_turn = true;
			rolled = true;
			timer_roll = 0;
			can_move = true;
			can_jump = true;
			if(key_down && ground)
			{
				state = "crouch";
				image_index = 3;
				image_speed = 0;	
			}
			else if(hspd == 0 && !key_down)
			{
				state = "idle";
				image_index = 0;
			}
			if(abs(hspd) > 0.3 && can_move = true && !place_meeting(x+_hspd*2, y, obj_Wall) && !key_down)
			{
				state = "walk";
				image_index = 0;
			}
			if(key_jump && ground)
			{
				state = "jump";
				image_index = 0; 
			}
			if(!ground)
			{
				state = "jump";
				image_index = 3;
			}
			if(key_attack)
			{
				if(cooldown <= 0)
				{
					state = "attack";
					image_index = 0;
				}
			}
			if(!ground && key_attack)
			{
				if(cooldown <= 0)
				{
					state = "jump attack";
					image_index = 0;
				}
			}
		}
		break;
	}
	case "attack":
	{
		can_move = false;
		can_turn = false;
		can_jump = false;
		image_speed = 1;
		if(equiped_weapon.stats.type_ == 2)
		{
			if(image_index >=3 && image_index <= 4)
			{
				image_speed = 3;
				if(attack != noone)
				{
					attack.mask_index = -1;
				}
			}
			else
			{
				image_speed = 0.5;
			}
			weapon.image_speed = image_speed;
			if(attack != noone)
			{
				attack.image_speed = image_speed;
			}
		}
		sprite_index = sprite_attack
		if(attack == noone)
		{
			attack = instance_create_layer(x, y, "Attack", equiped_weapon.object);
			attack.image_xscale = image_xscale;
			cooldown = attack.cooldown_timer;
		}
		if (image_speed > 0)
		{
			 if (image_index >= image_number - 1)
			 {
				image_speed = 0; 
			 }
		}
		if(image_speed == 0)
		{
			can_move = true;
			can_turn = true;
			can_jump = true;
			if(abs(hspd) > 0.3 && can_move = true && !place_meeting(x+_hspd*2, y, obj_Wall))
			{
				state = "walk";
				image_index = 0;
			}
			if(key_jump && ground)
			{
				state = "jump";
				image_index = 0; 
			}
			if(!ground)
			{
				state = "jump";
				image_index = 3;
			}
			if(key_down && ground)
			{
				state = "crouch";
				image_index = 0;
			}
			if(hspd = 0)
			{
				state = "idle";
				image_index = 0;
			}
			if(ground && key_roll && roll_cooldown >= 30)
			{
				rolled = false;
				state = "roll";
				image_index = 0
			}
		}
		if(!ground)
			{
				state = "jump attack";
			}
		break;
	}
	case "crouch attack":
	{
		can_move = false;
		can_turn = false;
		image_speed = 1;
		sprite_index = sprite_crouch_attack
		if(attack == noone)
		{
			attack = instance_create_layer(x+(image_xscale), y+5, "Attack", equiped_weapon.object);
			cooldown = attack.cooldown_timer;
			image_index = 0;
		}
		if(equiped_weapon.stats.type_ == 2)
		{
			if(image_index >=3 && image_index <= 4)
			{
				image_speed = 3;
				if(attack != noone)
				{
					attack.mask_index = -1;
				}
			}
			else
			{
				image_speed = 0.5;
			}
			weapon.image_speed = image_speed;
			if(attack != noone)
			{
				attack.image_xscale = image_xscale;
				attack.image_speed = image_speed;
			}
		}
		if (image_speed > 0)
		{
			 if (image_index >= image_number - 1)
			 {
				can_turn = true;
				image_speed = 0;	
				image_index = image_number - 1;
				state = "crouch";
			 }
		}
		
		break;
	}
	case "hurt":
	{
		damage = (damage_physical - def_physical) + (damage_fire - def_fire) + (damage_water - def_water) + (damage_thunder - def_thunder) + (damage_nature - def_nature)
		screenshake(3);
		can_move = false;
		can_turn = false;
		can_jump = false;
		if(show_damage == true && !invencible)
		{
			var _damage = instance_create_layer(x, y, "Attack", obj_Damage);
			_damage.damage = damage;
			_damage.target = id;
			_damage.is_player = true;
			show_damage = false
		}
		if(life - damage <= 0 && sprite_index != sprite_hurt)
		{
			screenshake(10);
			life = 0;
			state = "death"	
		}
		else
		{
			if damage > max_life * 0.025
			{
				sprite_index = sprite_hurt;
			}
			else
			{
				show_damage = true;
				can_attack = true;
				can_move = true;
				can_turn = true;
				can_jump = true;
				if(!invencible)
				{
					life -= damage;
					invencible = true;
					invencible_time = invencible_timer;
				}
				if(abs(hspd) > 0.3 && can_move = true && !place_meeting(x+_hspd*2, y, obj_Wall))
				{
					state = "walk";
					image_index = 0;
				}
				if(key_jump && ground)
				{
					state = "jump";
					image_index = 0; 
				}
				if(!ground)
				{
					state = "jump";
					image_index = 3;
				}
				if(key_down && ground)
				{
					state = "crouch";
					image_index = 0;
				}
				if(hspd = 0)
				{
					state = "idle";
					image_index = 0;
				}
				if(ground && key_roll && roll_cooldown >= 30)
				{
					rolled = false;
					state = "roll";
					image_index = 0
				}
				break;	
			}
			if(attack != noone)
			{
				instance_destroy(attack.id)	
			}
			if (vspd < 0)
			{
				vspd = 0;
			}
			can_attack = false;
			image_xscale = -hit;
			image_speed = 1;
			if(!place_meeting(x-(image_xscale*2), y, obj_Wall) && state != "death" && !rolling && damage > max_life * 0.025)
			{
				y -= 0.3;
				x += hit;
			}
			if(!invencible)
			{
				life -= damage;
				invencible = true;
				invencible_time = invencible_timer;
			}
			if (image_speed > 0)
			{
				if (image_index >= image_number - 1 || damage < 0.025)
				{
					show_damage = true;
					image_speed = 0;
					can_move = true;
					can_attack = true;
					can_turn = true;
					can_jump = true;
					if(abs(hspd) > 0.3 && can_move = true && !place_meeting(x+_hspd*2, y, obj_Wall))
					{
						state = "walk";
						image_index = 0;
					}
					if(key_jump && ground)
					{
						state = "jump";
						image_index = 0; 
					}
					if(!ground)
					{
						state = "jump";
						image_index = 3;
					}
					if(key_down && ground)
					{
						state = "crouch";
						image_index = 0;
					}
					if(hspd = 0)
					{
						state = "idle";
						image_index = 0;
					}
					if(ground && key_roll && roll_cooldown >= 30)
					{
						rolled = false;
						state = "roll";
						image_index = 0
					}
				}
			}
		}
		break;
	}
	case "jump attack":
	{
		can_turn = false;
		can_move = true;
		image_speed = 1;
		if (image_index == image_number - 1)
		{
			image_index = 0;
		}
		sprite_index = sprite_jump_attack
		if(attack == noone)
		{
			attack = instance_create_layer(x+(image_xscale), y, "Attack", equiped_weapon.object);
			cooldown = attack.cooldown_timer;
		}
		else
		{
			attack.x = x + image_xscale;
			attack.y = y -1;	
		}
		if(equiped_weapon.stats.type_ == 2)
		{
			if(image_index >=3 && image_index <= 4)
			{
				image_speed = 3;
				if(attack != noone)
				{
					attack.mask_index = -1;
				}
			}
			else
			{
				image_speed = 0.5;
			}
			weapon.image_speed = image_speed;
			if(attack != noone)
			{
				attack.image_xscale = image_xscale;
				attack.image_speed = image_speed;
			}
		}
		if (image_speed > 0)
		{
			 if (image_index >= image_number - 1)
			 {
				can_turn = true;
				can_move = true;
				image_speed = 0;	
				image_index = image_number - 1;
				if(!ground)
				{
					state = "jump";
				}
				else
				{
					if(key_down && ground)
					{
						state = "crouch";
						image_index = 0;
					}
					if((hspd = 0) && ground)
					{
						state = "idle";
						image_index = 0;
					}
					if(abs(hspd) > 0.3 && can_move = true && !place_meeting(x+_hspd*2, y, obj_Wall) && ground)
					{
						state = "walk";
						image_index = 0;
					}
				}
			 }
		}
		if(ground && image_speed > 0 && image_index > 1)
		{
			can_move = true;
			state = "attack";
			attack.y += 2;
			attack.x -= image_xscale;
		}
		break;
	}
	case "death":
	{
		can_move = false;
		can_turn = false;
		can_attack = false;
		invencible = true;
		image_xscale = -hit;
		image_speed = 1;
		sprite_index = sprite_death;
		if (image_index >= image_number - 0.2)
		{
			image_speed = 0;
		}
	}
	case "wall slide":
	{
		mass = 0.04;
		image_speed = 1;
		sprite_index = sprite_wall_slide;
		can_jump = true;
		can_move = true;
		hspd = key_right - key_left;
		if(key_right - key_left == 0)
		{
			hspd = wall;
		}
		if(key_jump)
		{
			mass = _mass;
			hspd = -2.5 * wall;
			state = "jump";
			image_index = 0; 
		}
		else if(ground || !place_meeting(x + hspd,y,obj_Wall) || wall == 0)
		{
			image_xscale = -image_xscale;
			mass = _mass;
			if(hspd == 0 && ground)
			{
				state = "idle";
				image_index = 0;
			}
			if(!ground)
			{
				state = "jump";
				image_index = 3;
			}
			if(abs(hspd) > 0.3 && can_move = true && !place_meeting(x+_hspd*2, y, obj_Wall) && ground)
			{
				state = "walk";
				image_index = 0;
			}
			if(key_down && ground)
			{
				state = "crouch";
				image_index = 0;
			}
			if(key_attack)
			{
				if(cooldown <= 0)
				{
					image_xscale = image_xscale*-1;
					state = "attack";
					image_index = 0;
				}
			}
			if(!ground && key_attack)
			{
				if(cooldown <= 0)
				{
					state = "jump attack";
					image_index = 0;
				}
			}
			if(ground && key_roll && roll_cooldown >= 30)
			{
				rolled = false;
				state = "roll";
				image_index = 0
			}
		}
		break;
	}
}
#endregion
#region COMBAT
roll_cooldown++;
weapon.image_alpha = image_alpha;
if(invencible && invencible_time > 0 && state != "death")
{
	invencible_time --;
	if(!rolling)
	{
		image_alpha = min(max(sin(get_timer()/30000),0.2),0.8)
	}
	if(attack != noone)
	{
		attack.image_alpha = image_alpha;
	}
}
else
{
	invencible = false;
	image_alpha = 1;
}
if(cooldown > 0)
{
	cooldown --;
}
#endregion
#region SKIN
	obj_Game_Controller.sprite_portait = equiped_armor.portait_;
	if(equiped_weapon.stats.type_ == 1)
	{
		sprite_attack = equiped_armor.skin1.attack1;
		sprite_crouch = equiped_armor.skin1.crouch1;
		sprite_crouch_attack = equiped_armor.skin1.crouchattack1;
		sprite_death = equiped_armor.skin1.death1;
		sprite_hurt = equiped_armor.skin1.hurt1;
		sprite_idle = equiped_armor.skin1.idle1;
		sprite_jump = equiped_armor.skin1.jump1;
		sprite_jump_attack = equiped_armor.skin1.jumpattack1;
		sprite_roll = equiped_armor.skin1.roll1;
		sprite_walk = equiped_armor.skin1.walk1;
		sprite_wall_slide = equiped_armor.skin1.wallslide1;
	}
	if(equiped_weapon.stats.type_ == 2)
	{
		sprite_attack = equiped_armor.skin2.attack2;
		sprite_crouch = equiped_armor.skin2.crouch2;
		sprite_crouch_attack = equiped_armor.skin2.crouchattack2;
		sprite_death = equiped_armor.skin2.death2;
		sprite_hurt = equiped_armor.skin2.hurt2;
		sprite_idle = equiped_armor.skin2.idle2;
		sprite_jump = equiped_armor.skin2.jump2;
		sprite_jump_attack = equiped_armor.skin2.jumpattack2;
		sprite_roll = equiped_armor.skin2.roll2;
		sprite_walk = equiped_armor.skin2.walk2;
		sprite_wall_slide = equiped_armor.skin2.wallslide2;
	}
	weapon.playerx = x;
	weapon.playery = y;
	weapon.state = state;
	weapon.sprite_type = equiped_weapon.stats.type_;
	weapon.sprite_idle = equiped_weapon.skin1.idle1;
	weapon.sprite_walk = equiped_weapon.skin1.walk1;
	weapon.sprite_crouch = equiped_weapon.skin1.crouch1;
	weapon.sprite_death = equiped_weapon.skin1.death1;
	weapon.sprite_hurt = equiped_weapon.skin1.hurt1;
	weapon.sprite_jump = equiped_weapon.skin1.jump1;
	weapon.sprite_roll = equiped_weapon.skin1.roll1;
	weapon.sprite_wall_slide = equiped_weapon.skin1.wallslide1;
#endregion
