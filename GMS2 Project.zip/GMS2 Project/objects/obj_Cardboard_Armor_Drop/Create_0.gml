/// @description Insert description here
// You can write your code in this editor

// Inherit the parent event
event_inherited();
item = global.item_list.cardboard_armor;
