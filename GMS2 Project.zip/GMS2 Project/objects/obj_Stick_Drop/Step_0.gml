if place_meeting(x, y, obj_Player)
{
	item_add(item);
	instance_destroy();
}
if y > yy - 3 && top = false
{
	y = lerp(y, yy - 3, 0.02)
	if( y <= yy - 2)
	{
		top = true
	}
}
if top = true
{
	y = lerp(y, yy, 0.02)
	if( y >= yy - 1)
	{
		top = false;	
	}
}