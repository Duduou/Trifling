item = global.item_list.club;
image_xscale = 0.5;
image_yscale = 0.5;
xx = x;
yy = y;
top = false