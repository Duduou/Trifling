event_inherited();
item = global.item_list.empty
