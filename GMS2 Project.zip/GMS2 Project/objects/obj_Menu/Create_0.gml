_scale = 3;
stats_page = 0;
menu_width = 54;
menu_height = 63;
i3 = 0;
i4 = 0;
item_type = noone;
accessory_number = 0;
reset_weapon = false;
reset_armor = false;
reset_accessory = false;
reset_item = false;
num_weapon = 0;
num_armor = 0;
num_accessory = 0;
num_item = 0;
#region POS
main_menu_pos = 0;
pos = 0;
pos1 = 0;
pos2 = 0;
pos3 = 0;
pos4 = 0;
pos5 = 0;
pos6 = 0;
pos7 = 0;
pos8 = 0;
pos9 = 0;
pos10 = 0;
pos11 = 0;
pos12 = 0;
#endregion
menu_level = 0;
main_menu_level = 0;
op_border = 14;
op_space = 24;
image_alpha = 0;
#region MENU // 0
main_menu_option[0,0] = "PLAY"
main_menu_option[0,1] = "OPTIONS"
main_menu_option[0,2] = "QUIT"
option[0, 0] = "ITEMS";
option[0, 1] = "EQUIPS";
option[0, 2] = "SKILLS";
option[0, 3] = "STATS";
option[0, 4] = "OPTIONS";
option[0, 5] = "QUIT";
#endregion
#region ITEMS // 1
option[1,0] = "ITEMS"
option[1,1]	= "KEY ITEMS"
#endregion
#region EQUIPS  //2
option[2,0] = "WEAPON";
option[2,1] = "ARMOR";
option[2,2] = "ACCESSORY 1";
option[2,3] = "ACCESSORY 2";
#endregion
#region SKILLS	//3

#endregion
#region STATS	//4
option[4,0] = "STATS";
option[4,1] = "BESTIARY";
option[4,2] = "COLECTION";
option[4,3] = "ACHIVEMENTS";
#endregion
#region OPTIONS	//5
option[5,0] = "VIDEO";
option[5,1] = "AUDIO";
option[5,2] = "CONTROLS";
option[5,3] = "GAMEPLAY";
#endregion
// 6 ITEMS
// 7 KEY ITEMS
// 8 WEAPONS
// 9 ARMOR
// 10 ACCESSORY 1
// 10 ACCESSORY 2
#region CONFIRM EQUIP 11
option[11, 0] = "YES";
option[11, 1] = "NO";
#endregion
#region CONFIRM USE 11
option[12, 0] = "YES";
option[12, 1] = "NO";
#endregion
#region OP_LENGTHS
main_menu_op_lenght = 0;
op_length = 0;
op_length1 = 0;
op_length2 = 0;
op_length3 = 0;
op_length4 = 0;
op_length5 = 0;
op_length6 = 0;
op_length7 = 0;
op_length8 = 0;
op_length9 = 0;
op_length10 = 0;
op_length11 = 0;
op_length12 = 0;
#endregion