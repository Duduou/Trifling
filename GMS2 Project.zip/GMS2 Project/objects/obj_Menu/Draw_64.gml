if(instance_exists(obj_Player) && room_get_name(room) != "rom_Main_Menu")
{
	if(obj_Player.show_menu)
	{
		var player_color = obj_Player.color_base
		draw_set_font(fnt_Pixel_2);
		draw_set_valign(fa_top);
		draw_set_valign(fa_left);
		var new_width = 0;
		for(var i = 0; i < op_length; i++)
		{
			var op_width = string_width(option[0,i]) * _scale;
			new_width = max(new_width, op_width);
		}
		menu_width = new_width + op_border * 2 - 1 * _scale;
		menu_height = op_border * 2 + string_height(option[0, 0]) * _scale + (op_length-1) * op_space - 7 * _scale;
		draw_sprite_ext(sprite_index, image_index, (+2 * _scale) * global._scalexx/4, (+30 * _scale) * global._scaleyy/4, (menu_width/sprite_width) * global._scalexx/4, (menu_height/sprite_height) * global._scaleyy/4, 0, c_white, 1);
		for(var i = 0; i < op_length; i++)
		{
			draw_set_color(c_white);
			if i == pos && menu_level == 0
			{
				draw_set_color(player_color);
			}
			draw_text_transformed(((2 * _scale) + op_border)* global._scalexx/4, ((30 * _scale) + op_border + op_space*i - 4 * _scale) * global._scaleyy/4, option[0,i], _scale * global._scalexx/4, _scale * global._scaleyy/4, 0);
		}
		if(menu_level == 1 || menu_level == 6 || menu_level == 7 || menu_level == 12)
		{
			draw_sprite_ext(spr_Arrow, image_index,(+ op_border + 1 + menu_width * 2.52 + _scale * -12)* global._scalexx/4, ((105 * _scale) + op_border + 2 + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, -90, c_white, 1);
			draw_sprite_ext(spr_Arrow, image_index,(+ op_border + 1 + menu_width * 2.52 + _scale * -70)* global._scalexx/4, ((105 * _scale) + op_border + 2 + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 90, c_white, 1);
		}
		if(menu_level == 2 || menu_level == 8 || menu_level == 9 || menu_level == 10 || menu_level == 11)
		{
			draw_sprite_ext(spr_Arrow, image_index,(+ op_border + 1 + menu_width * 2.52 + _scale * -12)* global._scalexx/4, ((121 * _scale) + op_border + 1 + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, -90, c_white, 1);
			draw_sprite_ext(spr_Arrow, image_index,(+ op_border + 1 + menu_width * 2.52 + _scale * -70)* global._scalexx/4, ((121 * _scale) + op_border + 1 + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 90, c_white, 1);
		}
		if(menu_level == 8 || menu_level == 9 || menu_level == 10)
		{
			draw_sprite_ext(spr_Arrow, image_index,(op_border + menu_width * 2.52 + _scale * 272)* global._scalexx/4, ((121 * _scale) + op_border + 1 + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, -90, c_white, 1);
			draw_sprite_ext(spr_Arrow, image_index,(op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((121 * _scale) + op_border + 1 + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 90, c_white, 1);
		}
		if(menu_level == 1 || menu_level == 6 || menu_level == 7 || menu_level == 12)
		{
			if(back_key && stats_page >= 0)
			{
				stats_page--;
			}
			if(back_key && stats_page < 0)
			{
				stats_page = 2;
			}
			if(next_key && stats_page <= 2)
			{
				stats_page++;
			}
			if(next_key && stats_page > 2)
			{
				stats_page = 0;
			}
			draw_sprite_ext(sprite_index, image_index, (menu_width + _scale * 3) * global._scalexx/4, (menu_width + _scale * 4) * global._scaleyy/4, ((menu_width/sprite_width) * 1.52) * global._scalexx/4, ((menu_height/sprite_height) * 1.5) * global._scaleyy/4, 0, c_white, 1);
			if(pos1 == 0)
			{
				draw_sprite_ext(spr_Item_Portait, image_index, (menu_width + _scale * 3 + op_border) * global._scalexx/4, (menu_width + _scale * 4 + op_border) * global._scaleyy/4, ((menu_width/sprite_width) * 3) * global._scalexx/4, ((menu_height/sprite_height) * 3) * global._scaleyy/4, 0, c_white, 1);
			}
			if(pos1 == 1)
			{
				draw_sprite_ext(spr_Key_Item_Portait, image_index, (menu_width + _scale * 3 + op_border) * global._scalexx/4, (menu_width + _scale * 4 + op_border) * global._scaleyy/4, ((menu_width/sprite_width) * 3) * global._scalexx/4, ((menu_height/sprite_height) * 3) * global._scaleyy/4, 0, c_white, 1);
			}
			draw_sprite_ext(sprite_index, image_index, (menu_width + _scale * 3) * global._scalexx/4, (+ 30 * _scale) * global._scaleyy/4, ((menu_width/sprite_width) * 1.52)* global._scalexx/4, ((menu_height/sprite_height) * 0.44)* global._scaleyy/4, 0, c_white, 1);
			draw_sprite_ext(sprite_index, image_index, (menu_width + _scale * 3) * global._scalexx/4, (menu_width + _scale * 88) * global._scaleyy/4, ((menu_width/sprite_width) * 1.52)* global._scalexx/4, ((menu_height/sprite_height) * 1.26)* global._scaleyy/4, 0, c_white, 1);
			if(stats_page == 0)
			{
				draw_sprite_ext(spr_Health, image_index, (op_border + 1 + menu_width + _scale * 2)* global._scalexx/4, ((35 * _scale) + op_border + 2 + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
				draw_sprite_ext(spr_Energy, image_index, (op_border + 1 + menu_width  + _scale * 2)* global._scalexx/4, ((47 * _scale) + op_border  + 2 + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
				draw_sprite_ext(spr_Damage, image_index, (op_border + 1 + menu_width + _scale * 2)* global._scalexx/4, ((59 * _scale) + op_border + 2 + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
				draw_sprite_ext(spr_Defense, image_index, (op_border + 1 + menu_width + _scale * 2)* global._scalexx/4, ((71 * _scale) + op_border + 2 + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
				draw_sprite_ext(spr_Speed, image_index, (op_border + 1 + menu_width + _scale * 2)* global._scalexx/4, ((83 * _scale) + op_border + 2+ op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
				draw_set_color(c_white);
				draw_text_ext_transformed( (op_border + 1 + menu_width + _scale * 15)* global._scalexx/4, ((34 * _scale) + 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, obj_Player.max_life, (3 * _scale), (90 * _scale), _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
				draw_text_ext_transformed( (op_border + 1 + menu_width + _scale * 15)* global._scalexx/4, ((46 * _scale) + 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, obj_Player.max_energy, (3 * _scale), (90 * _scale), _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
				draw_text_ext_transformed( (op_border + 1 + menu_width + _scale * 15)* global._scalexx/4, ((58 * _scale) + 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, obj_Player.dmg, (3 * _scale), (90 * _scale), _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
				draw_text_ext_transformed( (op_border + 1 + menu_width + _scale * 15)* global._scalexx/4, ((70 * _scale) + 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, obj_Player.defense, (3 * _scale), (90 * _scale), _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
				draw_text_ext_transformed( (op_border + 1 + menu_width + _scale * 15)* global._scalexx/4, ((82 * _scale) + 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, obj_Player.speed_, (3 * _scale), (90 * _scale), _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
			}
			if(stats_page == 1)
			{
				draw_sprite_ext(spr_Physical, image_index, (op_border + 1 + menu_width + _scale * 2)* global._scalexx/4, ((35 * _scale) + op_border + 2 + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
				draw_sprite_ext(spr_Fire, image_index, (op_border + 1 + menu_width  + _scale * 2)* global._scalexx/4, ((47 * _scale) + op_border  + 2 + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
				draw_sprite_ext(spr_Water, image_index, (op_border + 1 + menu_width + _scale * 2)* global._scalexx/4, ((59 * _scale) + op_border + 2 + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
				draw_sprite_ext(spr_Thunder, image_index, (op_border + 1 + menu_width + _scale * 2)* global._scalexx/4, ((71 * _scale) + op_border + 2 + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
				draw_sprite_ext(spr_Nature, image_index, (op_border + 1 + menu_width + _scale * 2)* global._scalexx/4, ((83 * _scale) + op_border + 2+ op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
				draw_set_color(c_white);
				draw_text_ext_transformed( (op_border + 1 + menu_width + _scale * 15)* global._scalexx/4, ((34 * _scale) + 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, obj_Player.atk_physical, (3 * _scale), (90 * _scale), _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
				draw_text_ext_transformed( (op_border + 1 + menu_width + _scale * 15)* global._scalexx/4, ((46 * _scale) + 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, obj_Player.atk_fire, (3 * _scale), (90 * _scale), _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
				draw_text_ext_transformed( (op_border + 1 + menu_width + _scale * 15)* global._scalexx/4, ((58 * _scale) + 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, obj_Player.atk_water, (3 * _scale), (90 * _scale), _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
				draw_text_ext_transformed( (op_border + 1 + menu_width + _scale * 15)* global._scalexx/4, ((70 * _scale) + 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, obj_Player.atk_thunder, (3 * _scale), (90 * _scale), _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
				draw_text_ext_transformed( (op_border + 1 + menu_width + _scale * 15)* global._scalexx/4, ((82 * _scale) + 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, obj_Player.atk_nature, (3 * _scale), (90 * _scale), _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
			}
			if(stats_page == 2)
			{
				draw_sprite_ext(spr_Physical_Resistence, image_index, (op_border + 1 + menu_width + _scale * 2)* global._scalexx/4, ((35 * _scale) + op_border + 2 + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
				draw_sprite_ext(spr_Fire_Resistence, image_index, (op_border + 1 + menu_width  + _scale * 2)* global._scalexx/4, ((47 * _scale) + op_border  + 2 + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
				draw_sprite_ext(spr_Water_Resistence, image_index, (op_border + 1 + menu_width + _scale * 2)* global._scalexx/4, ((59 * _scale) + op_border + 2 + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
				draw_sprite_ext(spr_Thunder_Resistence, image_index, (op_border + 1 + menu_width + _scale * 2)* global._scalexx/4, ((71 * _scale) + op_border + 2 + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
				draw_sprite_ext(spr_Nature_Resistence, image_index, (op_border + 1 + menu_width + _scale * 2)* global._scalexx/4, ((83 * _scale) + op_border + 2+ op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
				draw_set_color(c_white);
				draw_text_ext_transformed( (op_border + 1 + menu_width + _scale * 15)* global._scalexx/4, ((34 * _scale) + 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, obj_Player.def_physical, (3 * _scale), (90 * _scale), _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
				draw_text_ext_transformed( (op_border + 1 + menu_width + _scale * 15)* global._scalexx/4, ((46 * _scale) + 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, obj_Player.def_fire, (3 * _scale), (90 * _scale), _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
				draw_text_ext_transformed( (op_border + 1 + menu_width + _scale * 15)* global._scalexx/4, ((58 * _scale) + 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, obj_Player.def_water, (3 * _scale), (90 * _scale), _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
				draw_text_ext_transformed( (op_border + 1 + menu_width + _scale * 15)* global._scalexx/4, ((70 * _scale) + 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, obj_Player.def_thunder, (3 * _scale), (90 * _scale), _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
				draw_text_ext_transformed( (op_border + 1 + menu_width + _scale * 15)* global._scalexx/4, ((82 * _scale) + 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, obj_Player.def_nature, (3 * _scale), (90 * _scale), _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
			}
			for(var i = 0; i < op_length1; i++)
			{
				draw_set_color(c_white);
				if i == pos1 && menu_level == 1
				{
					draw_set_color(player_color);
				}
				draw_text_transformed(((2 * _scale) + op_border + menu_width + _scale * 3)* global._scalexx/4, (op_border + op_space*i + 1 + 26 * _scale)* global._scalexx/4, option[1,i], _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
			}
			if((op_length6 > 0 && menu_level == 6 || menu_level == 12) && item_type == "item")
			{
				draw_sprite_ext(sprite_index, image_index, (menu_width*2.52 + _scale * 4) * global._scalexx/4, (+30 * _scale)* global._scaleyy/4, ((menu_width/sprite_width) * 5.5)* global._scalexx/4, ((menu_height/sprite_height) * 1.5)* global._scaleyy/4, 0, c_white, 1);
				draw_sprite_ext(sprite_index, image_index, (menu_width*2.52 + 1 + _scale * 3.5) * global._scalexx/4, (menu_height * 2 + 1 + 3 * _scale)* global._scaleyy/4, ((menu_width/sprite_width) * 4)* global._scalexx/4, ((menu_height/sprite_height) * 2)* global._scaleyy/4, 0, c_white, 1);
				draw_sprite_ext(sprite_index, image_index, (menu_width*6.52 + 1 + _scale * 4.5) * global._scalexx/4, (menu_height * 2 + 1 + 3 * _scale)* global._scaleyy/4, ((menu_width/sprite_width) * 1.49)* global._scalexx/4, ((menu_height/sprite_height) * 2)* global._scaleyy/4, 0, c_white, 1);
				for(var i = 0; i < op_length6; i++)
				{
					var pos_alt = floor(pos6/3)-3;
					var alt = floor(i / 3);
					var i2 = i - alt * 3;
					i3 = i;
					if(pos_alt > 0 && pos_alt >= i4)
					{
						i3 += 3 * i4;
					}
					else
					{
						i3 += 3 * i4;
					}
					if(pos_alt > i4)
					{
						i4 = pos_alt;	
					}
					if(floor(pos6/3) < i4)
					{
						i4--;
					}
					draw_set_color(c_white);
					if i3 == pos6 && menu_level == 6
					{
						draw_set_color(player_color);
					}
					if(op_length6 > 14)
					{
						if(i4 != floor(op_length6/3) - 4)
						{
							draw_sprite_ext(spr_Arrow, image_index,(+ op_border + 1 + menu_width * 2.52 + _scale * 195)* global._scalexx/4, ((121 * _scale) + op_border + 1 + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 180, c_white, 1);
						}
						if(i4 != 0)
						{
							draw_sprite_ext(spr_Arrow, image_index,(+ op_border + 1 + menu_width * 2.52 + _scale * 8)* global._scalexx/4, ((121 * _scale) + op_border + 1 + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
						}
					}
					if(i <= 14 && menu_level == 6 || i <= 14 && menu_level == 12)
					{
						if(i3 <= op_length6 - 1)
						{
							draw_text_ext_transformed(((10 * _scale) + op_border + 1 + menu_width * 2.52 + _scale * 3 + i2 * _scale * 67)* global._scalexx/4, ((30 * _scale) + op_border + 1 + op_space * 2.5 * alt +  menu_height * 1.52)* global._scaleyy/4, option[6,i].nick, (3 * _scale), (18 * _scale), _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
							draw_sprite_ext(option[6,i].mini, image_index,(+ op_border + 1 + menu_width * 2.52 + _scale * 3 + i2 * _scale * 67)* global._scalexx/4, ((33 * _scale) + op_border + 1 + op_space * 2.5 * alt +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.5)* global._scalexx/4, (_scale * 0.5)* global._scaleyy/4, 0, c_white, 1);
							if(option[6,i] != global.item_list.none)
							{
								draw_text_ext_transformed((op_border + 1 + menu_width * 2.52 + _scale * 2.5 + i2 * _scale * 67)* global._scalexx/4, ((40 * _scale) + op_border + 1 + op_space * 2.5 * alt +  menu_height * 1.52)* global._scaleyy/4,"(" + string(option[6,i].stack) + ")", (3 * _scale), (18 * _scale), _scale * 0.5 * global._scalexx/4, _scale * 0.5 * global._scaleyy/4, 0);
							}
						}
					}
					if(pos6 >= 0 && pos6 < op_length6)
					{
						draw_set_color(c_white);
						draw_sprite_ext(option[6,pos6].portait, image_index, (menu_width + _scale * 3 + op_border) * global._scalexx/4, (menu_width + _scale * 4 + op_border) * global._scaleyy/4, ((menu_width/sprite_width) * 3)* global._scalexx/4, ((menu_height/sprite_height) * 3)* global._scaleyy/4, 0, c_white, 1)
						draw_text_ext_transformed(((6 * _scale) + op_border + menu_width * 2.52)* global._scalexx/4, ((8 * _scale) + op_border + 1 + op_space * 2.5)* global._scaleyy/4, option[6,pos6].description, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
						if(menu_level != 12)
						{
						
						}
					}
				}
				if(menu_level == 12)
				{
					draw_set_color(c_white)
					draw_text_transformed(((307 * _scale) + 1 + op_border + menu_width + _scale * 3)* global._scalexx/4, ((53 * _scale) + op_border + op_space - 4 * _scale +  menu_height * 1.52)* global._scaleyy/4, "USE?", _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
					for(var i = 0; i < op_length12; i++)
					{
						draw_set_color(c_white);
						if i == pos12 && menu_level == 12
						{
							draw_set_color(player_color);
						}
						draw_text_transformed(((310 * _scale) + op_border + menu_width + _scale * 3 + i * _scale * 3)* global._scalexx/4, ((78 * _scale) + op_border + op_space * i * 2 - 4 * _scale +  menu_height * 1.52)* global._scaleyy/4, option[12,i], _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
					}
				}
			}
		}
		else
		{
			pos6 = 0;
			pos7 = 0;
			pos12 = 0;
		}
		if(menu_level == 2 || menu_level == 8 || menu_level == 9 || menu_level == 10 || menu_level == 11)
		{
			if(back_key && stats_page >= 0)
			{
				stats_page--;
			}
			if(back_key && stats_page < 0)
			{
				stats_page = 2;
			}
			if(next_key && stats_page <= 2)
			{
				stats_page++;
			}
			if(next_key && stats_page > 2)
			{
				stats_page = 0;
			}
			draw_sprite_ext(sprite_index, image_index, (menu_width + _scale * 3) * global._scalexx/4, (menu_width + _scale * 20 - 1) * global._scaleyy/4, ((menu_width/sprite_width) * 1.52) * global._scalexx/4, ((menu_height/sprite_height) * 1.5) * global._scaleyy/4, 0, c_white, 1);
			if(pos2 == 0)
			{
				draw_sprite_ext(obj_Player.equiped_weapon.portait, image_index, (menu_width + _scale * 3 + op_border) * global._scalexx/4, (menu_width + _scale * 20 + op_border - 1) * global._scaleyy/4, ((menu_width/sprite_width) * 3) * global._scalexx/4, ((menu_height/sprite_height) * 3) * global._scaleyy/4, 0, c_white, 1);
			}
			if(pos2 == 1)
			{
				draw_sprite_ext(obj_Player.equiped_armor.portait, image_index, (menu_width + _scale * 3 + op_border) * global._scalexx/4, (menu_width + _scale * 20 + op_border - 1) * global._scaleyy/4, ((menu_width/sprite_width) * 3) * global._scalexx/4, ((menu_height/sprite_height) * 3) * global._scaleyy/4, 0, c_white, 1);
			}
			if(pos2 == 2)
			{
				draw_sprite_ext(obj_Player.equiped_accessory1.portait, image_index, (menu_width + _scale * 3 + op_border) * global._scalexx/4, (menu_width + _scale * 20 + op_border - 1) * global._scaleyy/4, ((menu_width/sprite_width) * 3) * global._scalexx/4, ((menu_height/sprite_height) * 3) * global._scaleyy/4, 0, c_white, 1);
			}
			if(pos2 == 3)
			{
				draw_sprite_ext(obj_Player.equiped_accessory2.portait, image_index, (menu_width + _scale * 3 + op_border) * global._scalexx/4, (menu_width + _scale * 20 + op_border - 1) * global._scaleyy/4, ((menu_width/sprite_width) * 3) * global._scalexx/4, ((menu_height/sprite_height) * 3) * global._scaleyy/4, 0, c_white, 1);
			}
			draw_sprite_ext(sprite_index, image_index, (menu_width + _scale * 3) * global._scalexx/4, (+ 30 * _scale) * global._scaleyy/4, ((menu_width/sprite_width) * 1.52)* global._scalexx/4, ((menu_height/sprite_height) * 0.72)* global._scaleyy/4, 0, c_white, 1);
			draw_sprite_ext(sprite_index, image_index, (menu_width + _scale * 3) * global._scalexx/4, (menu_width + _scale * 104 - 1) * global._scaleyy/4, ((menu_width/sprite_width) * 1.52)* global._scalexx/4, ((menu_height/sprite_height) * 1.26)* global._scaleyy/4, 0, c_white, 1);
			if(stats_page == 0)
			{
				draw_sprite_ext(spr_Health, image_index, (op_border + 1 + menu_width + _scale * 2)* global._scalexx/4, ((51 * _scale) + op_border + 2 + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
				draw_sprite_ext(spr_Energy, image_index, (op_border + 1 + menu_width  + _scale * 2)* global._scalexx/4, ((63 * _scale) + op_border  + 2 + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
				draw_sprite_ext(spr_Damage, image_index, (op_border + 1 + menu_width + _scale * 2)* global._scalexx/4, ((75 * _scale) + op_border + 2 + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
				draw_sprite_ext(spr_Defense, image_index, (op_border + 1 + menu_width + _scale * 2)* global._scalexx/4, ((87 * _scale) + op_border + 2 + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
				draw_sprite_ext(spr_Speed, image_index, (op_border + 1 + menu_width + _scale * 2)* global._scalexx/4, ((99 * _scale) + op_border + 2+ op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
				draw_set_color(c_white);
				draw_text_ext_transformed( (op_border + 1 + menu_width + _scale * 15)* global._scalexx/4, ((50 * _scale) + 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, obj_Player.max_life, (3 * _scale), (90 * _scale), _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
				draw_text_ext_transformed( (op_border + 1 + menu_width + _scale * 15)* global._scalexx/4, ((62 * _scale) + 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, obj_Player.max_energy, (3 * _scale), (90 * _scale), _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
				draw_text_ext_transformed( (op_border + 1 + menu_width + _scale * 15)* global._scalexx/4, ((74 * _scale) + 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, obj_Player.dmg, (3 * _scale), (90 * _scale), _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
				draw_text_ext_transformed( (op_border + 1 + menu_width + _scale * 15)* global._scalexx/4, ((86 * _scale) + 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, obj_Player.defense, (3 * _scale), (90 * _scale), _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
				draw_text_ext_transformed( (op_border + 1 + menu_width + _scale * 15)* global._scalexx/4, ((98 * _scale) + 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, obj_Player.speed_, (3 * _scale), (90 * _scale), _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
			}
			if(stats_page == 1)
			{
				draw_sprite_ext(spr_Physical, image_index, (op_border + 1 + menu_width + _scale * 2)* global._scalexx/4, ((51 * _scale) + op_border + 2 + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
				draw_sprite_ext(spr_Fire, image_index, (op_border + 1 + menu_width  + _scale * 2)* global._scalexx/4, ((63 * _scale) + op_border  + 2 + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
				draw_sprite_ext(spr_Water, image_index, (op_border + 1 + menu_width + _scale * 2)* global._scalexx/4, ((75 * _scale) + op_border + 2 + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
				draw_sprite_ext(spr_Thunder, image_index, (op_border + 1 + menu_width + _scale * 2)* global._scalexx/4, ((87 * _scale) + op_border + 2 + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
				draw_sprite_ext(spr_Nature, image_index, (op_border + 1 + menu_width + _scale * 2)* global._scalexx/4, ((99 * _scale) + op_border + 2+ op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
				draw_set_color(c_white);
				draw_text_ext_transformed( (op_border + 1 + menu_width + _scale * 15)* global._scalexx/4, ((50 * _scale) + 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, obj_Player.atk_physical, (3 * _scale), (90 * _scale), _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
				draw_text_ext_transformed( (op_border + 1 + menu_width + _scale * 15)* global._scalexx/4, ((62 * _scale) + 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, obj_Player.atk_fire, (3 * _scale), (90 * _scale), _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
				draw_text_ext_transformed( (op_border + 1 + menu_width + _scale * 15)* global._scalexx/4, ((74 * _scale) + 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, obj_Player.atk_water, (3 * _scale), (90 * _scale), _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
				draw_text_ext_transformed( (op_border + 1 + menu_width + _scale * 15)* global._scalexx/4, ((86 * _scale) + 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, obj_Player.atk_thunder, (3 * _scale), (90 * _scale), _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
				draw_text_ext_transformed( (op_border + 1 + menu_width + _scale * 15)* global._scalexx/4, ((98 * _scale) + 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, obj_Player.atk_nature, (3 * _scale), (90 * _scale), _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
			}
			if(stats_page == 2)
			{
				draw_sprite_ext(spr_Physical_Resistence, image_index, (op_border + 1 + menu_width + _scale * 2)* global._scalexx/4, ((51 * _scale) + op_border + 2 + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
				draw_sprite_ext(spr_Fire_Resistence, image_index, (op_border + 1 + menu_width  + _scale * 2)* global._scalexx/4, ((63 * _scale) + op_border  + 2 + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
				draw_sprite_ext(spr_Water_Resistence, image_index, (op_border + 1 + menu_width + _scale * 2)* global._scalexx/4, ((75 * _scale) + op_border + 2 + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
				draw_sprite_ext(spr_Thunder_Resistence, image_index, (op_border + 1 + menu_width + _scale * 2)* global._scalexx/4, ((87 * _scale) + op_border + 2 + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
				draw_sprite_ext(spr_Nature_Resistence, image_index, (op_border + 1 + menu_width + _scale * 2)* global._scalexx/4, ((99 * _scale) + op_border + 2+ op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
				draw_set_color(c_white);
				draw_text_ext_transformed( (op_border + 1 + menu_width + _scale * 15)* global._scalexx/4, ((50 * _scale) + 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, obj_Player.def_physical, (3 * _scale), (90 * _scale), _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
				draw_text_ext_transformed( (op_border + 1 + menu_width + _scale * 15)* global._scalexx/4, ((62 * _scale) + 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, obj_Player.def_fire, (3 * _scale), (90 * _scale), _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
				draw_text_ext_transformed( (op_border + 1 + menu_width + _scale * 15)* global._scalexx/4, ((74 * _scale) + 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, obj_Player.def_water, (3 * _scale), (90 * _scale), _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
				draw_text_ext_transformed( (op_border + 1 + menu_width + _scale * 15)* global._scalexx/4, ((86 * _scale) + 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, obj_Player.def_thunder, (3 * _scale), (90 * _scale), _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
				draw_text_ext_transformed( (op_border + 1 + menu_width + _scale * 15)* global._scalexx/4, ((98 * _scale) + 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, obj_Player.def_nature, (3 * _scale), (90 * _scale), _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
			}
			for(var i = 0; i < op_length2; i++)
			{
				draw_set_color(c_white);
				if i == pos2 && menu_level == 2
				{
					draw_set_color(player_color);
				}
				draw_text_transformed(((2 * _scale) + op_border + menu_width + _scale * 3)* global._scalexx/4, (op_border + op_space*i + 1 + 26 * _scale)* global._scalexx/4, option[2,i], _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
			}
			if((op_length8 > 0 && menu_level == 8 || menu_level == 11) && item_type == "weapon")
			{
				draw_sprite_ext(sprite_index, image_index, (menu_width*2.52 + _scale * 4) * global._scalexx/4, (+30 * _scale)* global._scaleyy/4, ((menu_width/sprite_width) * 5.5)* global._scalexx/4, ((menu_height/sprite_height) * 1.5)* global._scaleyy/4, 0, c_white, 1);
				draw_sprite_ext(sprite_index, image_index, (menu_width*2.52 + 1 + _scale * 3.5) * global._scalexx/4, (menu_height * 2 + 1 + 3 * _scale)* global._scaleyy/4, ((menu_width/sprite_width) * 4)* global._scalexx/4, ((menu_height/sprite_height) * 2)* global._scaleyy/4, 0, c_white, 1);
				draw_sprite_ext(sprite_index, image_index, (menu_width*6.52 + 1 + _scale * 4.5) * global._scalexx/4, (menu_height * 2 + 1 + 3 * _scale)* global._scaleyy/4, ((menu_width/sprite_width) * 1.49)* global._scalexx/4, ((menu_height/sprite_height) * 2)* global._scaleyy/4, 0, c_white, 1);
				for(var i = 0; i < op_length8; i++)
				{
					var pos_alt = floor(pos8/3)-3;
					var alt = floor(i / 3);
					var i2 = i - alt * 3;
					i3 = i;
					if(pos_alt > 0 && pos_alt >= i4)
					{
						i3 += 3 * i4;
					}
					else
					{
						i3 += 3 * i4;
					}
					if(pos_alt > i4)
					{
						i4 = pos_alt;	
					}
					if(floor(pos8/3) < i4)
					{
						i4--;
					}
					draw_set_color(c_white);
					if i3 == pos8 && menu_level == 8
					{
						draw_set_color(player_color);
					}
					if(op_length8 > 14)
					{
						if(i4 != floor(op_length8/3) - 4)
						{
							draw_sprite_ext(spr_Arrow, image_index,(+ op_border + 1 + menu_width * 2.52 + _scale * 195)* global._scalexx/4, ((121 * _scale) + op_border + 1 + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 180, c_white, 1);
						}
						if(i4 != 0)
						{
							draw_sprite_ext(spr_Arrow, image_index,(+ op_border + 1 + menu_width * 2.52 + _scale * 8)* global._scalexx/4, ((121 * _scale) + op_border + 1 + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
						}
					}
					if(i <= 14 && menu_level == 8 || i <= 14 && menu_level == 11)
					{
						if(i3 <= op_length8 - 1)
						{
							draw_text_ext_transformed(((10 * _scale) + op_border + 1 + menu_width * 2.52 + _scale * 3 + i2 * _scale * 67)* global._scalexx/4, ((30 * _scale) + op_border + 1 + op_space * 2.5 * alt +  menu_height * 1.52)* global._scaleyy/4, option[8,i].nick, (3 * _scale), (18 * _scale), _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
							draw_sprite_ext(option[8,i].mini, image_index,(+ op_border + 1 + menu_width * 2.52 + _scale * 3 + i2 * _scale * 67)* global._scalexx/4, ((33 * _scale) + op_border + 1 + op_space * 2.5 * alt +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.5)* global._scalexx/4, (_scale * 0.5)* global._scaleyy/4, 0, c_white, 1);
							if(option[8,i] != global.item_list.empty)
							{
								draw_text_ext_transformed((op_border + 1 + menu_width * 2.52 + _scale * 2.5 + i2 * _scale * 67)* global._scalexx/4, ((40 * _scale) + op_border + 1 + op_space * 2.5 * alt +  menu_height * 1.52)* global._scaleyy/4,"(" + string(option[8,i].stack) + ")", (3 * _scale), (18 * _scale), _scale * 0.5 * global._scalexx/4, _scale * 0.5 * global._scaleyy/4, 0);
							}
						}
					}
					if(pos8 >= 0 && pos8 < op_length8)
					{
						draw_set_color(c_white);
						draw_sprite_ext(option[8,pos8].portait, image_index, (menu_width + _scale * 3 + op_border) * global._scalexx/4, (menu_width + _scale * 20 + op_border) * global._scaleyy/4, ((menu_width/sprite_width) * 3)* global._scalexx/4, ((menu_height/sprite_height) * 3)* global._scaleyy/4, 0, c_white, 1)
						draw_text_ext_transformed(((6 * _scale) + op_border + menu_width * 2.52)* global._scalexx/4, ((8 * _scale) + op_border + 1 + op_space * 2.5)* global._scaleyy/4, option[8,pos8].description, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
						if(menu_level != 11)
						{
							if(stats_page == 0)
							{
								draw_sprite_ext(spr_Health, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((15 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								draw_sprite_ext(spr_Energy, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((35 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								draw_sprite_ext(spr_Damage, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((55 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								draw_sprite_ext(spr_Defense, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((75 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								draw_sprite_ext(spr_Speed, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((95 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((14 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[8,pos8].stats.health_, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
								draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((34 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[8,pos8].stats.energy, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
								draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((54 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[8,pos8].stats.damage, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
								draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((74 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[8,pos8].stats.defense, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
								draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((94 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[8,pos8].stats.speed_, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
							}
							if(stats_page == 1)
							{
								draw_sprite_ext(spr_Physical, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((15 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								draw_sprite_ext(spr_Fire, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((35 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								draw_sprite_ext(spr_Water, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((55 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								draw_sprite_ext(spr_Thunder, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((75 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								draw_sprite_ext(spr_Nature, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((95 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((14 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[8,pos8].stats.physical, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
								draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((34 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[8,pos8].stats.fire, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
								draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((54 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[8,pos8].stats.water, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
								draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((74 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[8,pos8].stats.thunder, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
								draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((94 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[8,pos8].stats.nature, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
							}
							if(stats_page == 2)
							{
								draw_sprite_ext(spr_Physical_Resistence, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((15 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								draw_sprite_ext(spr_Fire_Resistence, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((35 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								draw_sprite_ext(spr_Water_Resistence, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((55 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								draw_sprite_ext(spr_Thunder_Resistence, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((75 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								draw_sprite_ext(spr_Nature_Resistence, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((95 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((14 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[8,pos8].stats.physical_resistence, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
								draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((34 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[8,pos8].stats.fire_resistence, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
								draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((54 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[8,pos8].stats.water_resistence, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
								draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((74 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[8,pos8].stats.thunder_resistence, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
								draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((94 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[8,pos8].stats.nature_resistence, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
							}
							if(stats_page = 0)
							{
								if(option[8,pos8].stats.health_ > obj_Player.equiped_weapon.stats.health_)
								{
									draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((15 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
								if(option[8,pos8].stats.health_ < obj_Player.equiped_weapon.stats.health_)
								{
									draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((15 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
								if(option[8,pos8].stats.energy > obj_Player.equiped_weapon.stats.energy)
								{
									draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((35 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
								if(option[8,pos8].stats.energy < obj_Player.equiped_weapon.stats.energy)
								{
									draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((35 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
								if(option[8,pos8].stats.damage > obj_Player.equiped_weapon.stats.damage)
								{
									draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((55 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
								if(option[8,pos8].stats.damage < obj_Player.equiped_weapon.stats.damage)
								{
									draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((55 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
								if(option[8,pos8].stats.defense > obj_Player.equiped_weapon.stats.defense)
								{
									draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((75 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
								if(option[8,pos8].stats.defense < obj_Player.equiped_weapon.stats.defense)
								{
									draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((75 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
								if(option[8,pos8].stats.speed_ > obj_Player.equiped_weapon.stats.speed_)
								{
									draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((95 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
								if(option[8,pos8].stats.speed_ < obj_Player.equiped_weapon.stats.speed_)
								{
									draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((95 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
							}
							if(stats_page = 1)
							{
								if(option[8,pos8].stats.physical > obj_Player.equiped_weapon.stats.physical)
								{
									draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((15 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
								if(option[8,pos8].stats.physical < obj_Player.equiped_weapon.stats.physical)
								{
									draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((15 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
								if(option[8,pos8].stats.fire > obj_Player.equiped_weapon.stats.fire)
								{
									draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((35 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
								if(option[8,pos8].stats.fire < obj_Player.equiped_weapon.stats.fire)
								{
									draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((35 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
								if(option[8,pos8].stats.water > obj_Player.equiped_weapon.stats.water)
								{
									draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((55 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
								if(option[8,pos8].stats.water < obj_Player.equiped_weapon.stats.water)
								{
									draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((55 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
								if(option[8,pos8].stats.thunder > obj_Player.equiped_weapon.stats.thunder)
								{
									draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((75 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
								if(option[8,pos8].stats.thunder < obj_Player.equiped_weapon.stats.thunder)
								{
									draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((75 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
								if(option[8,pos8].stats.nature > obj_Player.equiped_weapon.stats.nature)
								{
									draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((95 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
								if(option[8,pos8].stats.nature < obj_Player.equiped_weapon.stats.nature)
								{
									draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((95 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
							}
							if(stats_page = 2)
							{
								if(option[8,pos8].stats.physical_resistence > obj_Player.equiped_weapon.stats.physical_resistence)
								{
									draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((15 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
								if(option[8,pos8].stats.physical_resistence < obj_Player.equiped_weapon.stats.physical_resistence)
								{
									draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((15 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
								if(option[8,pos8].stats.fire_resistence > obj_Player.equiped_weapon.stats.fire_resistence)
								{
									draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((35 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
								if(option[8,pos8].stats.fire_resistence < obj_Player.equiped_weapon.stats.fire_resistence)
								{
									draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((35 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
								if(option[8,pos8].stats.water_resistence > obj_Player.equiped_weapon.stats.water_resistence)
								{
									draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((55 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
								if(option[8,pos8].stats.water_resistence < obj_Player.equiped_weapon.stats.water_resistence)
								{
									draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((55 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
								if(option[8,pos8].stats.thunder_resistence > obj_Player.equiped_weapon.stats.thunder_resistence)
								{
									draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((75 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
								if(option[8,pos8].stats.thunder_resistence < obj_Player.equiped_weapon.stats.thunder_resistence)
								{
									draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((75 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
								if(option[8,pos8].stats.nature_resistence > obj_Player.equiped_weapon.stats.nature_resistence)
								{
									draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((95 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
								if(option[8,pos8].stats.nature_resistence < obj_Player.equiped_weapon.stats.nature_resistence)
								{
									draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((95 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
							}
						}
					}
				}
				if(menu_level == 11)
				{
					draw_set_color(c_white)
					draw_text_transformed(((301 * _scale) + 1 + op_border + menu_width + _scale * 3)* global._scalexx/4, ((53 * _scale) + op_border + op_space - 4 * _scale +  menu_height * 1.52)* global._scaleyy/4, "EQUIP?", _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
					for(var i = 0; i < op_length11; i++)
					{
						draw_set_color(c_white);
						if i == pos11 && menu_level == 11
						{
							draw_set_color(player_color);
						}
						draw_text_transformed(((310 * _scale) + op_border + menu_width + _scale * 3 + i * _scale * 3)* global._scalexx/4, ((78 * _scale) + op_border + op_space * i * 2 - 4 * _scale +  menu_height * 1.52)* global._scaleyy/4, option[11,i], _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
					}
				}
			}
			if((op_length9 > 0 && menu_level == 9 || menu_level == 11) && item_type == "armor")
			{
				draw_sprite_ext(sprite_index, image_index, (menu_width*2.52 + _scale * 4) * global._scalexx/4, (+30 * _scale)* global._scaleyy/4, ((menu_width/sprite_width) * 5.5)* global._scalexx/4, ((menu_height/sprite_height) * 1.5)* global._scaleyy/4, 0, c_white, 1);
				draw_sprite_ext(sprite_index, image_index, (menu_width*2.52 + 1 + _scale * 3.5) * global._scalexx/4, (menu_height * 2 + 1 + 3 * _scale)* global._scaleyy/4, ((menu_width/sprite_width) * 4)* global._scalexx/4, ((menu_height/sprite_height) * 2)* global._scaleyy/4, 0, c_white, 1);
				draw_sprite_ext(sprite_index, image_index, (menu_width*6.52 + 1 + _scale * 4.5) * global._scalexx/4, (menu_height * 2 + 1 + 3 * _scale)* global._scaleyy/4, ((menu_width/sprite_width) * 1.485)* global._scalexx/4, ((menu_height/sprite_height) * 2)* global._scaleyy/4, 0, c_white, 1);
				for(var i = 0; i < op_length9; i++)
				{
					var pos_alt = floor(pos9/3)-3;
					var alt = floor(i / 3);
					var i2 = i - alt * 3;
					i3 = i;
					if(pos_alt > 0 && pos_alt >= i4)
					{
						i3 += 3 * i4;
					}
					else
					{
						i3 += 3 * i4;
					}
					if(pos_alt > i4)
					{
						i4 = pos_alt;	
					}
					if(floor(pos9/3) < i4)
					{
						i4--;
					}
					draw_set_color(c_white);
					if i3 == pos9 && menu_level == 9
					{
						draw_set_color(player_color);
					}
					if(op_length9 > 14)
					{
						if(i4 != floor(op_length9/3) - 4)
						{
							draw_sprite_ext(spr_Arrow, image_index,(+ op_border + 1 + menu_width * 2.52 + _scale * 195)* global._scalexx/4, ((121 * _scale) + op_border + 1 + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 180, c_white, 1);
						}
						if(i4 != 0)
						{
							draw_sprite_ext(spr_Arrow, image_index,(+ op_border + 1 + menu_width * 2.52 + _scale * 8)* global._scalexx/4, ((121 * _scale) + op_border + 1 + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
						}
					}
					if(i <= 14 && menu_level == 9 || i <= 14 && menu_level == 11)
					{
						if(i3 <= op_length9 - 1)
						{
							draw_text_ext_transformed(((10 * _scale) + op_border + 1 + menu_width * 2.52 + _scale * 3 + i2 * _scale * 67)* global._scalexx/4, ((30 * _scale) + op_border + 1 + op_space * 2.5 * alt +  menu_height * 1.52)* global._scaleyy/4, option[9,i].nick, (3 * _scale), (18 * _scale), _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
							draw_sprite_ext(option[9,i].mini, image_index,(+ op_border + 1 + menu_width * 2.52 + _scale * 3 + i2 * _scale * 67)* global._scalexx/4, ((33 * _scale) + op_border + 1 + op_space * 2.5 * alt +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.5)* global._scalexx/4, (_scale * 0.5)* global._scaleyy/4, 0, c_white, 1);
							if(option[9,i] != global.item_list.none)
							{
								draw_text_ext_transformed((op_border + 1 + menu_width * 2.52 + _scale * 2.5 + i2 * _scale * 67)* global._scalexx/4, ((40 * _scale) + op_border + 1 + op_space * 2.5 * alt +  menu_height * 1.52)* global._scaleyy/4,"(" + string(option[9,i].stack) + ")", (3 * _scale), (18 * _scale), _scale * 0.5 * global._scalexx/4, _scale * 0.5 * global._scaleyy/4, 0);
							}
						}
					}
					if(pos9 >= 0 && pos9 < op_length9)
					{
						draw_set_color(c_white);
						draw_sprite_ext(option[9,pos9].portait, image_index, (menu_width + _scale * 3 + op_border) * global._scalexx/4, (menu_width + _scale * 20 + op_border) * global._scaleyy/4, ((menu_width/sprite_width) * 3)* global._scalexx/4, ((menu_height/sprite_height) * 3)* global._scaleyy/4, 0, c_white, 1)
						draw_text_ext_transformed(((6 * _scale) + op_border + menu_width * 2.52)* global._scalexx/4, ((8 * _scale) + op_border + 1 + op_space * 2.5)* global._scaleyy/4, option[9,pos9].description, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
						if(menu_level != 11)
						{
							if(stats_page == 0)
							{
								draw_sprite_ext(spr_Health, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((15 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								draw_sprite_ext(spr_Energy, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((35 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								draw_sprite_ext(spr_Damage, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((55 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								draw_sprite_ext(spr_Defense, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((75 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								draw_sprite_ext(spr_Speed, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((95 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((14 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[9,pos9].stats.health_, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
								draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((34 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[9,pos9].stats.energy, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
								draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((54 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[9,pos9].stats.damage, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
								draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((74 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[9,pos9].stats.defense, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
								draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((94 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[9,pos9].stats.speed_, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
							}
							if(stats_page == 1)
							{
								draw_sprite_ext(spr_Physical, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((15 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								draw_sprite_ext(spr_Fire, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((35 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								draw_sprite_ext(spr_Water, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((55 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								draw_sprite_ext(spr_Thunder, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((75 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								draw_sprite_ext(spr_Nature, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((95 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((14 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[9,pos9].stats.physical, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
								draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((34 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[9,pos9].stats.fire, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
								draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((54 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[9,pos9].stats.water, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
								draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((74 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[9,pos9].stats.thunder, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
								draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((94 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[9,pos9].stats.nature, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
							}
							if(stats_page == 2)
							{
								draw_sprite_ext(spr_Physical_Resistence, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((15 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								draw_sprite_ext(spr_Fire_Resistence, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((35 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								draw_sprite_ext(spr_Water_Resistence, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((55 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								draw_sprite_ext(spr_Thunder_Resistence, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((75 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								draw_sprite_ext(spr_Nature_Resistence, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((95 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((14 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[9,pos9].stats.physical_resistence, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
								draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((34 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[9,pos9].stats.fire_resistence, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
								draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((54 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[9,pos9].stats.water_resistence, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
								draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((74 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[9,pos9].stats.thunder_resistence, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
								draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((94 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[9,pos9].stats.nature_resistence, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
							}
							if(stats_page = 0)
							{
								if(option[9,pos9].stats.health_ > obj_Player.equiped_armor.stats.health_)
								{
									draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((15 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
								if(option[9,pos9].stats.health_ < obj_Player.equiped_armor.stats.health_)
								{
									draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((15 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
								if(option[9,pos9].stats.energy > obj_Player.equiped_armor.stats.energy)
								{
									draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((35 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
								if(option[9,pos9].stats.energy < obj_Player.equiped_armor.stats.energy)
								{
									draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((35 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
								if(option[9,pos9].stats.damage > obj_Player.equiped_armor.stats.damage)
								{
									draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((55 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
								if(option[9,pos9].stats.damage < obj_Player.equiped_armor.stats.damage)
								{
									draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((55 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
								if(option[9,pos9].stats.defense > obj_Player.equiped_armor.stats.defense)
								{
									draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((75 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
								if(option[9,pos9].stats.defense < obj_Player.equiped_armor.stats.defense)
								{
									draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((75 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
								if(option[9,pos9].stats.speed_ > obj_Player.equiped_armor.stats.speed_)
								{
									draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((95 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
								if(option[9,pos9].stats.speed_ < obj_Player.equiped_armor.stats.speed_)
								{
									draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((95 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
							}
							if(stats_page = 1)
							{
								if(option[9,pos9].stats.physical > obj_Player.equiped_armor.stats.physical)
								{
									draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((15 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
								if(option[9,pos9].stats.physical < obj_Player.equiped_armor.stats.physical)
								{
									draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((15 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
								if(option[9,pos9].stats.fire > obj_Player.equiped_armor.stats.fire)
								{
									draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((35 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
								if(option[9,pos9].stats.fire < obj_Player.equiped_armor.stats.fire)
								{
									draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((35 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
								if(option[9,pos9].stats.water > obj_Player.equiped_armor.stats.water)
								{
									draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((55 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
								if(option[9,pos9].stats.water < obj_Player.equiped_armor.stats.water)
								{
									draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((55 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
								if(option[9,pos9].stats.thunder > obj_Player.equiped_armor.stats.thunder)
								{
									draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((75 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
								if(option[9,pos9].stats.thunder < obj_Player.equiped_armor.stats.thunder)
								{
									draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((75 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
								if(option[9,pos9].stats.nature > obj_Player.equiped_armor.stats.nature)
								{
									draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((95 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
								if(option[9,pos9].stats.nature < obj_Player.equiped_armor.stats.nature)
								{
									draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((95 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
							}
							if(stats_page = 2)
							{
								if(option[9,pos9].stats.physical_resistence > obj_Player.equiped_armor.stats.physical_resistence)
								{
									draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((15 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
								if(option[9,pos9].stats.physical_resistence < obj_Player.equiped_armor.stats.physical_resistence)
								{
									draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((15 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
								if(option[9,pos9].stats.fire_resistence > obj_Player.equiped_armor.stats.fire_resistence)
								{
									draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((35 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
								if(option[9,pos9].stats.fire_resistence < obj_Player.equiped_armor.stats.fire_resistence)
								{
									draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((35 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
								if(option[9,pos9].stats.water_resistence > obj_Player.equiped_armor.stats.water_resistence)
								{
									draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((55 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
								if(option[9,pos9].stats.water_resistence < obj_Player.equiped_armor.stats.water_resistence)
								{
									draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((55 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
								if(option[9,pos9].stats.thunder_resistence > obj_Player.equiped_armor.stats.thunder_resistence)
								{
									draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((75 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
								if(option[9,pos9].stats.thunder_resistence < obj_Player.equiped_armor.stats.thunder_resistence)
								{
									draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((75 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
								if(option[9,pos9].stats.nature_resistence > obj_Player.equiped_armor.stats.nature_resistence)
								{
									draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((95 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
								if(option[9,pos9].stats.nature_resistence < obj_Player.equiped_armor.stats.nature_resistence)
								{
									draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((95 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
								}
							}
						}
					}
				}
				if(menu_level == 11)
				{
					draw_set_color(c_white)
					draw_text_transformed(((301 * _scale) + 1 + op_border + menu_width + _scale * 3)* global._scalexx/4, ((53 * _scale) + op_border + op_space - 4 * _scale +  menu_height * 1.52)* global._scaleyy/4, "EQUIP?", _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
					for(var i = 0; i < op_length11; i++)
					{
						draw_set_color(c_white);
						if i == pos11 && menu_level == 11
						{
							draw_set_color(player_color);
						}
						draw_text_transformed(((310 * _scale) + op_border + menu_width + _scale * 3 + i * _scale * 3)* global._scalexx/4, ((78 * _scale) + op_border + op_space * i * 2 - 4 * _scale +  menu_height * 1.52)* global._scaleyy/4, option[11,i], _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
					}
				}
			}
			if((op_length10 > 0 && menu_level == 10 || menu_level == 11) && item_type == "accessory")
			{
				if accessory_number == 1
				{
					draw_sprite_ext(sprite_index, image_index, (menu_width*2.52 + _scale * 4) * global._scalexx/4, (+30 * _scale)* global._scaleyy/4, ((menu_width/sprite_width) * 5.5)* global._scalexx/4, ((menu_height/sprite_height) * 1.5)* global._scaleyy/4, 0, c_white, 1);
					draw_sprite_ext(sprite_index, image_index, (menu_width*2.52 + 1 + _scale * 3.5) * global._scalexx/4, (menu_height * 2 + 1 + 3 * _scale)* global._scaleyy/4, ((menu_width/sprite_width) * 4)* global._scalexx/4, ((menu_height/sprite_height) * 2)* global._scaleyy/4, 0, c_white, 1);
					draw_sprite_ext(sprite_index, image_index, (menu_width*6.52 + 1 + _scale * 4.5) * global._scalexx/4, (menu_height * 2 + 1 + 3 * _scale)* global._scaleyy/4, ((menu_width/sprite_width) * 1.49)* global._scalexx/4, ((menu_height/sprite_height) * 2)* global._scaleyy/4, 0, c_white, 1);
					for(var i = 0; i < op_length10; i++)
					{
						var pos_alt = floor(pos10/3)-3;
						var alt = floor(i / 3);
						var i2 = i - alt * 3;
						i3 = i;
						if(pos_alt > 0 && pos_alt >= i4)
						{
							i3 += 3 * i4;
						}
						else
						{
							i3 += 3 * i4;
						}
						if(pos_alt > i4)
						{
							i4 = pos_alt;	
						}
						if(floor(pos10/3) < i4)
						{
							i4--;
						}
						draw_set_color(c_white);
						if i3 == pos10 && menu_level == 10
						{
							draw_set_color(player_color);
						}
						if(op_length10 > 14)
						{
							if(i4 != floor(op_length10/3) - 4)
							{
								draw_sprite_ext(spr_Arrow, image_index,(+ op_border + 1 + menu_width * 2.52 + _scale * 195)* global._scalexx/4, ((121 * _scale) + op_border + 1 + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 180, c_white, 1);
							}
							if(i4 != 0)
							{
								draw_sprite_ext(spr_Arrow, image_index,(+ op_border + 1 + menu_width * 2.52 + _scale * 8)* global._scalexx/4, ((121 * _scale) + op_border + 1 + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
							}
						}
						if(i <= 14 && menu_level == 10 || i <= 14 && menu_level == 11)
						{
							if(i3 <= op_length10 - 1)
							{
								draw_text_ext_transformed(((10 * _scale) + op_border + 1 + menu_width * 2.52 + _scale * 3 + i2 * _scale * 67)* global._scalexx/4, ((30 * _scale) + op_border + 1 + op_space * 2.5 * alt +  menu_height * 1.52)* global._scaleyy/4, option[10,i].nick, (3 * _scale), (18 * _scale), _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
								draw_sprite_ext(option[10,i].mini, image_index,(+ op_border + 1 + menu_width * 2.52 + _scale * 3 + i2 * _scale * 67)* global._scalexx/4, ((33 * _scale) + op_border + 1 + op_space * 2.5 * alt +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.5)* global._scalexx/4, (_scale * 0.5)* global._scaleyy/4, 0, c_white, 1);
								if(option[10,i] != global.item_list.none)
								{
									draw_text_ext_transformed((op_border + 1 + menu_width * 2.52 + _scale * 2.5 + i2 * _scale * 67)* global._scalexx/4, ((40 * _scale) + op_border + 1 + op_space * 2.5 * alt +  menu_height * 1.52)* global._scaleyy/4,"(" + string(option[10,i].stack) + ")", (3 * _scale), (18 * _scale), _scale * 0.5 * global._scalexx/4, _scale * 0.5 * global._scaleyy/4, 0);
								}
							}
						}
						if(pos10 >= 0 && pos10 < op_length10)
						{
							draw_set_color(c_white);
							draw_sprite_ext(option[10,pos10].portait, image_index, (menu_width + _scale * 3 + op_border) * global._scalexx/4, (menu_width + _scale * 20 + op_border) * global._scaleyy/4, ((menu_width/sprite_width) * 3)* global._scalexx/4, ((menu_height/sprite_height) * 3)* global._scaleyy/4, 0, c_white, 1)
							draw_text_ext_transformed(((6 * _scale) + op_border + menu_width * 2.52)* global._scalexx/4, ((8 * _scale) + op_border + 1 + op_space * 2.5)* global._scaleyy/4, option[10,pos10].description, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
							if(menu_level != 11)
							{
								if(stats_page == 0)
								{
									draw_sprite_ext(spr_Health, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((15 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									draw_sprite_ext(spr_Energy, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((35 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									draw_sprite_ext(spr_Damage, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((55 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									draw_sprite_ext(spr_Defense, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((75 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									draw_sprite_ext(spr_Speed, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((95 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((14 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[10,pos10].stats.health_, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
									draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((34 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[10,pos10].stats.energy, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
									draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((54 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[10,pos10].stats.damage, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
									draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((74 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[10,pos10].stats.defense, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
									draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((94 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[10,pos10].stats.speed_, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
								}
								if(stats_page == 1)
								{
									draw_sprite_ext(spr_Physical, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((15 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									draw_sprite_ext(spr_Fire, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((35 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									draw_sprite_ext(spr_Water, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((55 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									draw_sprite_ext(spr_Thunder, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((75 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									draw_sprite_ext(spr_Nature, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((95 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((14 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[10,pos10].stats.physical, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
									draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((34 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[10,pos10].stats.fire, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
									draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((54 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[10,pos10].stats.water, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
									draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((74 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[10,pos10].stats.thunder, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
									draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((94 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[10,pos10].stats.nature, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
								}
								if(stats_page == 2)
								{
									draw_sprite_ext(spr_Physical_Resistence, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((15 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									draw_sprite_ext(spr_Fire_Resistence, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((35 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									draw_sprite_ext(spr_Water_Resistence, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((55 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									draw_sprite_ext(spr_Thunder_Resistence, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((75 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									draw_sprite_ext(spr_Nature_Resistence, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((95 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((14 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[10,pos10].stats.physical_resistence, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
									draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((34 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[10,pos10].stats.fire_resistence, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
									draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((54 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[10,pos10].stats.water_resistence, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
									draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((74 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[10,pos10].stats.thunder_resistence, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
									draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((94 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[10,pos10].stats.nature_resistence, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
								}
								if(stats_page = 0)
								{
									if(option[10,pos10].stats.health_ > obj_Player.equiped_accessory1.stats.health_)
									{
										draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((15 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
									if(option[10,pos10].stats.health_ < obj_Player.equiped_accessory1.stats.health_)
									{
										draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((15 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
									if(option[10,pos10].stats.energy > obj_Player.equiped_accessory1.stats.energy)
									{
										draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((35 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
									if(option[10,pos10].stats.energy < obj_Player.equiped_accessory1.stats.energy)
									{
										draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((35 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
									if(option[10,pos10].stats.damage > obj_Player.equiped_accessory1.stats.damage)
									{
										draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((55 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
									if(option[10,pos10].stats.damage < obj_Player.equiped_accessory1.stats.damage)
									{
										draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((55 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
									if(option[10,pos10].stats.defense > obj_Player.equiped_accessory1.stats.defense)
									{
										draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((75 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
									if(option[10,pos10].stats.defense < obj_Player.equiped_accessory1.stats.defense)
									{
										draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((75 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
									if(option[10,pos10].stats.speed_ > obj_Player.equiped_accessory1.stats.speed_)
									{
										draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((95 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
									if(option[10,pos10].stats.speed_ < obj_Player.equiped_accessory1.stats.speed_)
									{
										draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((95 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
								}
								if(stats_page = 1)
								{
									if(option[10,pos10].stats.physical > obj_Player.equiped_accessory1.stats.physical)
									{
										draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((15 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
									if(option[10,pos10].stats.physical < obj_Player.equiped_accessory1.stats.physical)
									{
										draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((15 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
									if(option[10,pos10].stats.fire > obj_Player.equiped_accessory1.stats.fire)
									{
										draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((35 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
									if(option[10,pos10].stats.fire < obj_Player.equiped_accessory1.stats.fire)
									{
										draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((35 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
									if(option[10,pos10].stats.water > obj_Player.equiped_accessory1.stats.water)
									{
										draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((55 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
									if(option[10,pos10].stats.water < obj_Player.equiped_accessory1.stats.water)
									{
										draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((55 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
									if(option[10,pos10].stats.thunder > obj_Player.equiped_accessory1.stats.thunder)
									{
										draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((75 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
									if(option[10,pos10].stats.thunder < obj_Player.equiped_accessory1.stats.thunder)
									{
										draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((75 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
									if(option[10,pos10].stats.nature > obj_Player.equiped_accessory1.stats.nature)
									{
										draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((95 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
									if(option[10,pos10].stats.nature < obj_Player.equiped_accessory1.stats.nature)
									{
										draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((95 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
								}
								if(stats_page = 2)
								{
									if(option[10,pos10].stats.physical_resistence > obj_Player.equiped_accessory1.stats.physical_resistence)
									{
										draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((15 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
									if(option[10,pos10].stats.physical_resistence < obj_Player.equiped_accessory1.stats.physical_resistence)
									{
										draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((15 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
									if(option[10,pos10].stats.fire_resistence > obj_Player.equiped_accessory1.stats.fire_resistence)
									{
										draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((35 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
									if(option[10,pos10].stats.fire_resistence < obj_Player.equiped_accessory1.stats.fire_resistence)
									{
										draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((35 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
									if(option[10,pos10].stats.water_resistence > obj_Player.equiped_accessory1.stats.water_resistence)
									{
										draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((55 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
									if(option[10,pos10].stats.water_resistence < obj_Player.equiped_accessory1.stats.water_resistence)
									{
										draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((55 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
									if(option[10,pos10].stats.thunder_resistence > obj_Player.equiped_accessory1.stats.thunder_resistence)
									{
										draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((75 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
									if(option[10,pos10].stats.thunder_resistence < obj_Player.equiped_accessory1.stats.thunder_resistence)
									{
										draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((75 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
									if(option[10,pos10].stats.nature_resistence > obj_Player.equiped_accessory1.stats.nature_resistence)
									{
										draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((95 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
									if(option[10,pos10].stats.nature_resistence < obj_Player.equiped_accessory1.stats.nature_resistence)
									{
										draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((95 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
								}
							}
						}
					}
					if(menu_level == 11)
					{
						draw_set_color(c_white)
						draw_text_transformed(((301 * _scale) + 1 + op_border + menu_width + _scale * 3)* global._scalexx/4, ((53 * _scale) + op_border + op_space - 4 * _scale +  menu_height * 1.52)* global._scaleyy/4, "EQUIP?", _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
						for(var i = 0; i < op_length11; i++)
						{
							draw_set_color(c_white);
							if i == pos11 && menu_level == 11
							{
								draw_set_color(player_color);
							}
							draw_text_transformed(((310 * _scale) + op_border + menu_width + _scale * 3 + i * _scale * 3)* global._scalexx/4, ((78 * _scale) + op_border + op_space * i * 2 - 4 * _scale +  menu_height * 1.52)* global._scaleyy/4, option[11,i], _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
						}
					}
				}
				if accessory_number == 2
				{
					draw_sprite_ext(sprite_index, image_index, (menu_width*2.52 + _scale * 4) * global._scalexx/4, (+30 * _scale)* global._scaleyy/4, ((menu_width/sprite_width) * 5.5)* global._scalexx/4, ((menu_height/sprite_height) * 1.5)* global._scaleyy/4, 0, c_white, 1);
					draw_sprite_ext(sprite_index, image_index, (menu_width*2.52 + 1 + _scale * 3.5) * global._scalexx/4, (menu_height * 2 + 1 + 3 * _scale)* global._scaleyy/4, ((menu_width/sprite_width) * 4)* global._scalexx/4, ((menu_height/sprite_height) * 2)* global._scaleyy/4, 0, c_white, 1);
					draw_sprite_ext(sprite_index, image_index, (menu_width*6.52 + 1 + _scale * 4.5) * global._scalexx/4, (menu_height * 2 + 1 + 3 * _scale)* global._scaleyy/4, ((menu_width/sprite_width) * 1.49)* global._scalexx/4, ((menu_height/sprite_height) * 2)* global._scaleyy/4, 0, c_white, 1);
					for(var i = 0; i < op_length10; i++)
					{
						var pos_alt = floor(pos10/3)-3;
						var alt = floor(i / 3);
						var i2 = i - alt * 3;
						i3 = i;
						if(pos_alt > 0 && pos_alt >= i4)
						{
							i3 += 3 * i4;
						}
						else
						{
							i3 += 3 * i4;
						}
						if(pos_alt > i4)
						{
							i4 = pos_alt;	
						}
						if(floor(pos10/3) < i4)
						{
							i4--;
						}
						draw_set_color(c_white);
						if i3 == pos10 && menu_level == 10
						{
							draw_set_color(player_color);
						}
						if(op_length10 > 14)
						{
							if(i4 != floor(op_length10/3) - 4)
							{
								draw_sprite_ext(spr_Arrow, image_index,(+ op_border + 1 + menu_width * 2.52 + _scale * 195)* global._scalexx/4, ((121 * _scale) + op_border + 1 + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 180, c_white, 1);
							}
							if(i4 != 0)
							{
								draw_sprite_ext(spr_Arrow, image_index,(+ op_border + 1 + menu_width * 2.52 + _scale * 8)* global._scalexx/4, ((121 * _scale) + op_border + 1 + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
							}
						}
						if(i <= 14 && menu_level == 10 || i <= 14 && menu_level == 11)
						{
							if(i3 <= op_length10 - 1)
							{
								draw_text_ext_transformed(((10 * _scale) + op_border + 1 + menu_width * 2.52 + _scale * 3 + i2 * _scale * 67)* global._scalexx/4, ((30 * _scale) + op_border + 1 + op_space * 2.5 * alt +  menu_height * 1.52)* global._scaleyy/4, option[10,i].nick, (3 * _scale), (18 * _scale), _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
								draw_sprite_ext(option[10,i].mini, image_index,(+ op_border + 1 + menu_width * 2.52 + _scale * 3 + i2 * _scale * 67)* global._scalexx/4, ((33 * _scale) + op_border + 1 + op_space * 2.5 * alt +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.5)* global._scalexx/4, (_scale * 0.5)* global._scaleyy/4, 0, c_white, 1);
								if(option[10,i] != global.item_list.none)
								{
									draw_text_ext_transformed((op_border + 1 + menu_width * 2.52 + _scale * 2.5 + i2 * _scale * 67)* global._scalexx/4, ((40 * _scale) + op_border + 1 + op_space * 2.5 * alt +  menu_height * 1.52)* global._scaleyy/4,"(" + string(option[10,i].stack) + ")", (3 * _scale), (18 * _scale), _scale * 0.5 * global._scalexx/4, _scale * 0.5 * global._scaleyy/4, 0);
								}
							}
						}
						if(pos10 >= 0 && pos10 < op_length10)
						{
							draw_set_color(c_white);
							draw_sprite_ext(option[10,pos10].portait, image_index, (menu_width + _scale * 3 + op_border) * global._scalexx/4, (menu_width + _scale * 20 + op_border) * global._scaleyy/4, ((menu_width/sprite_width) * 3)* global._scalexx/4, ((menu_height/sprite_height) * 3)* global._scaleyy/4, 0, c_white, 1)
							draw_text_ext_transformed(((6 * _scale) + op_border + menu_width * 2.52)* global._scalexx/4, ((8 * _scale) + op_border + 1 + op_space * 2.5)* global._scaleyy/4, option[10,pos10].description, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
							if(menu_level != 11)
							{
								if(stats_page == 0)
								{
									draw_sprite_ext(spr_Health, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((15 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									draw_sprite_ext(spr_Energy, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((35 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									draw_sprite_ext(spr_Damage, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((55 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									draw_sprite_ext(spr_Defense, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((75 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									draw_sprite_ext(spr_Speed, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((95 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((14 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[10,pos10].stats.health_, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
									draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((34 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[10,pos10].stats.energy, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
									draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((54 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[10,pos10].stats.damage, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
									draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((74 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[10,pos10].stats.defense, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
									draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((94 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[10,pos10].stats.speed_, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
								}
								if(stats_page == 1)
								{
									draw_sprite_ext(spr_Physical, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((15 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									draw_sprite_ext(spr_Fire, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((35 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									draw_sprite_ext(spr_Water, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((55 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									draw_sprite_ext(spr_Thunder, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((75 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									draw_sprite_ext(spr_Nature, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((95 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((14 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[10,pos10].stats.physical, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
									draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((34 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[10,pos10].stats.fire, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
									draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((54 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[10,pos10].stats.water, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
									draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((74 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[10,pos10].stats.thunder, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
									draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((94 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[10,pos10].stats.nature, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
								}
								if(stats_page == 2)
								{
									draw_sprite_ext(spr_Physical_Resistence, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((15 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									draw_sprite_ext(spr_Fire_Resistence, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((35 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									draw_sprite_ext(spr_Water_Resistence, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((55 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									draw_sprite_ext(spr_Thunder_Resistence, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((75 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									draw_sprite_ext(spr_Nature_Resistence, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 215)* global._scalexx/4, ((95 * _scale) + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((14 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[10,pos10].stats.physical_resistence, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
									draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((34 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[10,pos10].stats.fire_resistence, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
									draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((54 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[10,pos10].stats.water_resistence, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
									draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((74 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[10,pos10].stats.thunder_resistence, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
									draw_text_ext_transformed( (op_border + 1 + menu_width * 2.52 + _scale * 230)* global._scalexx/4, ((94 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, option[10,pos10].stats.nature_resistence, 3 * _scale, 90 * _scale, _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
								}
								if(stats_page = 0)
								{
									if(option[10,pos10].stats.health_ > obj_Player.equiped_accessory2.stats.health_)
									{
										draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((15 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
									if(option[10,pos10].stats.health_ < obj_Player.equiped_accessory2.stats.health_)
									{
										draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((15 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
									if(option[10,pos10].stats.energy > obj_Player.equiped_accessory2.stats.energy)
									{
										draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((35 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
									if(option[10,pos10].stats.energy < obj_Player.equiped_accessory2.stats.energy)
									{
										draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((35 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
									if(option[10,pos10].stats.damage > obj_Player.equiped_accessory2.stats.damage)
									{
										draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((55 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
									if(option[10,pos10].stats.damage < obj_Player.equiped_accessory2.stats.damage)
									{
										draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((55 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
									if(option[10,pos10].stats.defense > obj_Player.equiped_accessory2.stats.defense)
									{
										draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((75 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
									if(option[10,pos10].stats.defense < obj_Player.equiped_accessory2.stats.defense)
									{
										draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((75 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
									if(option[10,pos10].stats.speed_ > obj_Player.equiped_accessory2.stats.speed_)
									{
										draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((95 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
									if(option[10,pos10].stats.speed_ < obj_Player.equiped_accessory2.stats.speed_)
									{
										draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((95 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
								}
								if(stats_page = 1)
								{
									if(option[10,pos10].stats.physical > obj_Player.equiped_accessory2.stats.physical)
									{
										draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((15 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
									if(option[10,pos10].stats.physical < obj_Player.equiped_accessory2.stats.physical)
									{
										draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((15 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
									if(option[10,pos10].stats.fire > obj_Player.equiped_accessory2.stats.fire)
									{
										draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((35 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
									if(option[10,pos10].stats.fire < obj_Player.equiped_accessory2.stats.fire)
									{
										draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((35 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
									if(option[10,pos10].stats.water > obj_Player.equiped_accessory2.stats.water)
									{
										draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((55 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
									if(option[10,pos10].stats.water < obj_Player.equiped_accessory2.stats.water)
									{
										draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((55 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
									if(option[10,pos10].stats.thunder > obj_Player.equiped_accessory2.stats.thunder)
									{
										draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((75 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
									if(option[10,pos10].stats.thunder < obj_Player.equiped_accessory2.stats.thunder)
									{
										draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((75 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
									if(option[10,pos10].stats.nature > obj_Player.equiped_accessory2.stats.nature)
									{
										draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((95 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
									if(option[10,pos10].stats.nature < obj_Player.equiped_accessory2.stats.nature)
									{
										draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((95 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
								}
								if(stats_page = 2)
								{
									if(option[10,pos10].stats.physical_resistence > obj_Player.equiped_accessory2.stats.physical_resistence)
									{
										draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((15 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
									if(option[10,pos10].stats.physical_resistence < obj_Player.equiped_accessory2.stats.physical_resistence)
									{
										draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((15 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
									if(option[10,pos10].stats.fire_resistence > obj_Player.equiped_accessory2.stats.fire_resistence)
									{
										draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((35 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
									if(option[10,pos10].stats.fire_resistence < obj_Player.equiped_accessory2.stats.fire_resistence)
									{
										draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((35 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
									if(option[10,pos10].stats.water_resistence > obj_Player.equiped_accessory2.stats.water_resistence)
									{
										draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((55 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
									if(option[10,pos10].stats.water_resistence < obj_Player.equiped_accessory2.stats.water_resistence)
									{
										draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((55 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
									if(option[10,pos10].stats.thunder_resistence > obj_Player.equiped_accessory2.stats.thunder_resistence)
									{
										draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((75 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
									if(option[10,pos10].stats.thunder_resistence < obj_Player.equiped_accessory2.stats.thunder_resistence)
									{
										draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((75 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
									if(option[10,pos10].stats.nature_resistence > obj_Player.equiped_accessory2.stats.nature_resistence)
									{
										draw_sprite_ext(spr_Better, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((95 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
									if(option[10,pos10].stats.nature_resistence < obj_Player.equiped_accessory2.stats.nature_resistence)
									{
										draw_sprite_ext(spr_Worst, image_index, (op_border + 1 + menu_width * 2.52 + _scale * 265)* global._scalexx/4, ((95 * _scale) - 1 + op_border + op_space * 2.5 +  menu_height * 1.52)* global._scaleyy/4, (_scale * 0.7)* global._scalexx/4, (_scale * 0.7)* global._scaleyy/4, 0, c_white, 1);
									}
								}
							}
						}
					}
					if(menu_level == 11)
					{
						draw_set_color(c_white)
						draw_text_transformed(((301 * _scale) + 1 + op_border + menu_width + _scale * 3)* global._scalexx/4, ((53 * _scale) + op_border + op_space - 4 * _scale +  menu_height * 1.52)* global._scaleyy/4, "EQUIP?", _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
						for(var i = 0; i < op_length11; i++)
						{
							draw_set_color(c_white);
							if i == pos11 && menu_level == 11
							{
								draw_set_color(player_color);
							}
							draw_text_transformed(((310 * _scale) + op_border + menu_width + _scale * 3 + i * _scale * 3)* global._scalexx/4, ((78 * _scale) + op_border + op_space * i * 2 - 4 * _scale +  menu_height * 1.52)* global._scaleyy/4, option[11,i], _scale* global._scalexx/4, _scale* global._scaleyy/4, 0);
						}
					}
				}
			}
		}
		else
		{
			pos8 = 0;
			pos9 = 0;
			pos10 = 0;
			pos11 = 0;
		}
	}
	//show_debug_message(menu_height) //63
	//show_debug_message(menu_width) //54
}
if(room_get_name(room) == "rom_Main_Menu")
{
	draw_set_font(fnt_Pixel_2);
	draw_set_valign(fa_top);
	draw_set_valign(fa_left);
	if(main_menu_pos == 0)
	{
		draw_sprite_ext(sprite_index, image_index,	5 * global._scalexx, 72 * global._scaleyy, 0.55 * global._scalexx, 0.2 * global._scaleyy, 0, c_white, 1);
		draw_text_transformed_color(16 * global._scalexx + 3, 74 * global._scaleyy, main_menu_option[0,0], 0.7 * global._scalexx, 0.7 * global._scaleyy, 0, $0109E6, $0109E6, $0109E6, $0109E6, 1);
		draw_sprite_ext(sprite_index, image_index,	5 * global._scalexx, 89 * global._scaleyy, 0.55 * global._scalexx, 0.2 * global._scaleyy, 0, c_white, 1);
		draw_text_transformed_color(10 * global._scalexx + 1, 91 * global._scaleyy, main_menu_option[0,1], 0.7 * global._scalexx, 0.7 * global._scaleyy, 0, c_white, c_white, c_white, c_white, 1);
		draw_sprite_ext(sprite_index, image_index,	5 * global._scalexx, 106 * global._scaleyy, 0.55 * global._scalexx, 0.2 * global._scaleyy, 0, c_white, 1);
		draw_text_transformed_color(17 * global._scalexx - 1, 108 * global._scaleyy, main_menu_option[0,2], 0.7 * global._scalexx, 0.7 * global._scaleyy, 0, c_white, c_white, c_white, c_white, 1);
	}
	if(main_menu_pos == 1)
	{
		draw_sprite_ext(sprite_index, image_index,	5 * global._scalexx, 72 * global._scaleyy, 0.55 * global._scalexx, 0.2 * global._scaleyy, 0, c_white, 1);
		draw_text_transformed_color(16 * global._scalexx + 3, 74 * global._scaleyy, main_menu_option[0,0], 0.7 * global._scalexx, 0.7 * global._scaleyy, 0, c_white, c_white, c_white, c_white, 1);
		draw_sprite_ext(sprite_index, image_index,	5 * global._scalexx, 89 * global._scaleyy, 0.55 * global._scalexx, 0.2 * global._scaleyy, 0, c_white, 1);
		draw_text_transformed_color(10 * global._scalexx + 1, 91 * global._scaleyy, main_menu_option[0,1], 0.7 * global._scalexx, 0.7 * global._scaleyy, 0, $0109E6, $0109E6, $0109E6, $0109E6, 1);
		draw_sprite_ext(sprite_index, image_index,	5 * global._scalexx, 106 * global._scaleyy, 0.55 * global._scalexx, 0.2 * global._scaleyy, 0, c_white, 1);
		draw_text_transformed_color(17 * global._scalexx - 1, 108 * global._scaleyy, main_menu_option[0,2], 0.7 * global._scalexx, 0.7 * global._scaleyy, 0, c_white, c_white, c_white, c_white, 1);
	}
	if(main_menu_pos == 2)
	{
		draw_sprite_ext(sprite_index, image_index,	5 * global._scalexx, 72 * global._scaleyy, 0.55 * global._scalexx, 0.2 * global._scaleyy, 0, c_white, 1);
		draw_text_transformed_color(16 * global._scalexx + 3, 74 * global._scaleyy, main_menu_option[0,0], 0.7 * global._scalexx, 0.7 * global._scaleyy, 0, c_white, c_white, c_white, c_white, 1);
		draw_sprite_ext(sprite_index, image_index,	5 * global._scalexx, 89 * global._scaleyy, 0.55 * global._scalexx, 0.2 * global._scaleyy, 0, c_white, 1);
		draw_text_transformed_color(10 * global._scalexx + 1, 91 * global._scaleyy, main_menu_option[0,1], 0.7 * global._scalexx, 0.7 * global._scaleyy, 0, c_white, c_white, c_white, c_white, 1);
		draw_sprite_ext(sprite_index, image_index,	5 * global._scalexx, 106 * global._scaleyy, 0.55 * global._scalexx, 0.2 * global._scaleyy, 0, c_white, 1);
		draw_text_transformed_color(17 * global._scalexx - 1, 108 * global._scaleyy, main_menu_option[0,2], 0.7 * global._scalexx, 0.7 * global._scaleyy, 0, $0109E6, $0109E6, $0109E6, $0109E6, 1);
	}
}
