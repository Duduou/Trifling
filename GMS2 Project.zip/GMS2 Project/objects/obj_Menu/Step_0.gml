#region CONTROLS
	up_key = keyboard_check_pressed(ord("W"));
	down_key = keyboard_check_pressed(ord("S"));
	left_key = keyboard_check_pressed(ord("A"));
	right_key = keyboard_check_pressed(ord("D"));
	confirm_key = keyboard_check_pressed(ord("J"));
	return_key = keyboard_check_pressed(ord("K"));
	back_key = keyboard_check_pressed(ord("Q"));
	next_key = keyboard_check_pressed(ord("E"));
#endregion	
if(instance_exists(obj_Player) && room_get_name(room) != "rom_Main_Menu")
{
	#region RESETS
		if(menu_level = 0)
		{
			pos1 = 0;
			pos2 = 0;
			pos3 = 0;
			pos4 = 0;
			pos5 = 0;
			pos6 = 0;
			pos7 = 0;
			pos8 = 0;
			pos9 = 0;
			pos10 = 0;
			pos11 = 0;
			pos12 = 0;
			stats_page = 0;
		}
		if(reset_weapon)
		{
			pos8 = 0;
			pos11 = 0;
			for(var i = 0; i < num_weapon; i++)
			{
				array_delete(option[8],0,1);
				if(array_length(option[8]) == 0)
				{
					reset_weapon = false;	
				}
			}
		}
		if(reset_armor)
		{
			pos9 = 0;
			pos11 = 0;
			for(var i = 0; i < num_armor; i++)
			{
				array_delete(option[9],0,1);
				if(array_length(option[9]) == 0)
				{
					reset_armor = false;	
				}
			}
		}
		if(reset_accessory)
		{
			pos10 = 0;
			pos11 = 0;
			for(var i = 0; i < num_accessory; i++)
			{
				array_delete(option[10],0,1);
				if(array_length(option[10]) == 0)
				{
					reset_accessory = false;	
				}
			}
		}
		if(reset_item)
		{
			pos6 = 0;
			pos12 = 0;
			for(var i = 0; i < num_item; i++)
			{
				array_delete(option[6],0,1);
				if(array_length(option[6]) == 0)
				{
					reset_item = false;	
				}
			}
		}
		#endregion
	if(obj_Player.show_menu)
	{
		#region CURSOR
		if(menu_level == 0)
		{
			pos += down_key - up_key;
		}
	
		if(menu_level == 1)
		{
			pos1 += down_key - up_key;
		}
	
		if(menu_level == 2)
		{
			pos2 += down_key - up_key;
		}
		if(menu_level == 3)
		{
			pos3 += down_key - up_key;
		}
	
		if(menu_level == 4)
		{
			pos4 += down_key - up_key;
		}
	
		if(menu_level == 5)
		{
			pos5 += down_key - up_key;
		}
		if(menu_level == 6)
		{
			pos6 += down_key - up_key;
		}
	
		if(menu_level == 7)
		{
			pos7 += down_key - up_key;
		}
	
		if(menu_level == 8)
		{
		
			if(pos8 == 0 && pos8 == op_length8 - 1)
			{
			
			}
			else if(pos8%3 == 0 && pos8 == op_length8 - 1)
			{
				if up_key
				{
					pos8 -= 3;	
				}
			}
			else if(pos8%3 != 0 && pos8 == op_length8 - 1)
			{
				if(right_key || left_key)
				{
					pos8 -= 1;	
				}
				if up_key && pos8 > 3
				{
					pos8 -= 3;	
				}
				else if up_key && pos8 < 4
				{
					pos8 = 0	
				}
			}
			else if(pos8%3 == 0 && pos8 == op_length8 - 2)
			{
				if(right_key || left_key)
				{
					pos8 += 1;	
				}
				if up_key && pos8 > 4 
				{
					pos8 -= 3;	
				}
				else if up_key && pos8 < 4
				{
					pos8 = 0	
				}
				if down_key
				{
					pos8 = op_length8 - 1;	
				}
			}
			else
			{
				if!(pos8 + 3 > op_length8 - 1)
				{
					pos8 += down_key * 3;
				}
				else
				{
					if down_key
					{
						pos8 = op_length8 - 1;
					}
				}
				if!(pos8 - 3 < 0)
				{
					pos8 -= up_key * 3;
				}
				else
				{
					if up_key
					{
						pos8 = 0;	
					}
				}
				if((pos8+1)%3 == 0)
				{
					if(right_key)
					{
						pos8 -= 3;
					}
				}
				if((pos8)%3 == 0)
				{
					if(left_key)
					{
						pos8 += 3;
					}
				}
				pos8 += right_key - left_key;
			}
		}
	
		if(menu_level == 9)
		{
		
			if(pos9 == 0 && pos9 == op_length9 - 1)
			{
			
			}
			else if(pos9%3 == 0 && pos9 == op_length9 - 1)
			{
				if up_key
				{
					pos9 -= 3;	
				}
			}
			else if(pos9%3 != 0 && pos9 == op_length9 - 1)
			{
				if(right_key || left_key)
				{
					pos9 -= 1;	
				}
				if up_key && pos9 > 3
				{
					pos9 -= 3;	
				}
				else if up_key && pos9 < 4
				{
					pos9 = 0	
				}
			}
			else if(pos9%3 == 0 && pos9 == op_length9 - 2)
			{
				if(right_key || left_key)
				{
					pos9 += 1;	
				}
				if up_key && pos9 > 4 
				{
					pos9 -= 3;	
				}
				else if up_key && pos9 < 4
				{
					pos9 = 0	
				}
				if down_key
				{
					pos9 = op_length9 - 1;	
				}
			}
			else
			{
				if!(pos9 + 3 > op_length9 - 1)
				{
					pos9 += down_key * 3;
				}
				else
				{
					if down_key
					{
						pos9 = op_length9 - 1;
					}
				}
				if!(pos9 - 3 < 0)
				{
					pos9 -= up_key * 3;
				}
				else
				{
					if up_key
					{
						pos9 = 0;	
					}
				}
				if((pos9+1)%3 == 0)
				{
					if(right_key)
					{
						pos9 -= 3;
					}
				}
				if((pos9)%3 == 0)
				{
					if(left_key)
					{
						pos9 += 3;
					}
				}
				pos9 += right_key - left_key;
			}
		}
	
		if(menu_level == 10)
		{
		
			if(pos10 == 0 && pos10 == op_length10 - 1)
			{
			
			}
			else if(pos10%3 == 0 && pos10 == op_length10 - 1)
			{
				if up_key
				{
					pos10 -= 3;	
				}
			}
			else if(pos10%3 != 0 && pos10 == op_length10 - 1)
			{
				if(right_key || left_key)
				{
					pos10 -= 1;	
				}
				if up_key && pos10 > 3
				{
					pos10 -= 3;	
				}
				else if up_key && pos10 < 4
				{
					pos10 = 0	
				}
			}
			else if(pos10%3 == 0 && pos10 == op_length10 - 2)
			{
				if(right_key || left_key)
				{
					pos10 += 1;	
				}
				if up_key && pos10 > 4 
				{
					pos10 -= 3;	
				}
				else if up_key && pos10 < 4
				{
					pos10 = 0	
				}
				if down_key
				{
					pos10 = op_length10 - 1;	
				}
			}
			else
			{
				if!(pos10 + 3 > op_length10 - 1)
				{
					pos10 += down_key * 3;
				}
				else
				{
					if down_key
					{
						pos10 = op_length10 - 1;
					}
				}
				if!(pos10 - 3 < 0)
				{
					pos10 -= up_key * 3;
				}
				else
				{
					if up_key
					{
						pos10 = 0;	
					}
				}
				if((pos10+1)%3 == 0)
				{
					if(right_key)
					{
						pos10 -= 3;
					}
				}
				if((pos10)%3 == 0)
				{
					if(left_key)
					{
						pos10 += 3;
					}
				}
				pos10 += right_key - left_key;
			}
		}
	
		if(menu_level == 11)
		{
			pos11 += down_key - up_key;
		}
	
		if(menu_level == 12)
		{
			pos12 += down_key - up_key;
		}
	
		if pos >= op_length
		{
			pos = 0;	
		}
		if pos < 0
		{
			pos = op_length - 1;	
		}
		op_length = array_length(option[0]);
	
		if pos1 >= op_length1
		{
			pos1 = 0;	
		}
		if pos1 < 0
		{
			pos1 = op_length1 - 1;	
		}
		op_length1 = array_length(option[1]);
	
		if pos2 >= op_length2
		{
			pos2 = 0;	
		}
		if pos2 < 0
		{
			pos2 = op_length2 - 1;	
		}
		op_length2 = array_length(option[2]);
	
		//if pos3 >= op_length3
		//{
		//	pos3 = 0;	
		//}
		//if pos3 < 0
		//{
		//	pos3 = op_length3 - 1;	
		//}
		//op_length3 = array_length(option[3]);
	
		//if pos4 >= op_length4
		//{
		//	pos4 = 0;	
		//}
		//if pos4 < 0
		//{
		//	pos4 = op_length4 - 1;	
		//}
		//op_length4 = array_length(option[4]);
	
		//if pos5 >= op_length5
		//{
		//	pos5 = 0;	
		//}
		//if pos5 < 0
		//{
		//	pos5 = op_length5 - 1;	
		//}
		//op_length5 = array_length(option[5]);

		op_length6 = array_length(option[6]);

		op_length7 = array_length(option[7]); 
	
		op_length8 = array_length(option[8]);
	
		op_length9 = array_length(option[9]);
	
		op_length10 = array_length(option[10]);
	
		if pos11 >= op_length11
		{
			pos11 = 0;	
		}
		if pos11 < 0
		{
			pos11 = op_length11 - 1;	
		}
		op_length11 = array_length(option[11]);
	
		if pos12 >= op_length12
		{
			pos12 = 0;	
		}
		if pos12 < 0
		{
			pos12 = op_length12 - 1;	
		}
		op_length12 = array_length(option[12]);
		#endregion
		if(confirm_key)
		{
			switch(menu_level)
			{
				case 0: //MAIN MENU
				{
					switch(pos)
					{
						case 0: //ITEMS
						{
							menu_level = 1;
							break;
						}
						case 1: //EQUIPS
						{
							menu_level = 2;
							break;
						}
						case 2: //SKILLS
						{
							menu_level = 3;
							break;
						}
						case 3: //STATS
						{
							menu_level = 4;
							break;
						}
						case 4: //OPTIONS
						{
							menu_level = 5;
							break;
						}
						case 5: //EXIT
						{
							room_goto(rom_Main_Menu);
							break;
						}
					}
					break;
				}
				case 1: //ITEMS
				{
					switch(pos1)
					{
						case 0: //ITEM
						{
							if op_length6 && !reset_item
							{
								item_type = "item";
								menu_level = 6;	
							}
							break;
						}
						case 1: //KEY ITEM
						{
							if op_length7
							{
								item_type = "key_item";
								menu_level = 7;	
							}
							break;
						}
					}
					break;
				}
				case 2: //EQIPS
				{
					switch(pos2)
					{
						case 0: //WEAPON
						{
							if op_length8 && !reset_weapon
							{
								item_type = "weapon";
								menu_level = 8;	
							}
							break;
						}
						case 1: //ARMOR
						{
							if op_length9 && !reset_armor
							{
								item_type = "armor";
								menu_level = 9;	
							}
							break;
						}
						case 2: //ACESSORY 1
						{
							if op_length10 && !reset_accessory
							{
								item_type = "accessory";
								accessory_number = 1;
								menu_level = 10;	
							}
							break;
						}
						case 3: //ACESSORY 2
						{
							if op_length10 && !reset_accessory
							{
								item_type = "accessory";
								accessory_number = 2;
								menu_level = 10;	
							}
							break;
						}
					}
					break;
				}
				case 6:
				{
					item_type = "item";
					menu_level = 12;
					break;
				}
				case 7:
				{
					item_type = "key_item";
					break;
				}
				case 8:
				{
					item_type = "weapon";
					menu_level = 11;
					break;
				}
				case 9:
				{
					item_type = "armor";
					menu_level = 11;
					break;
				}
				case 10:
				{
					item_type = "accessory";
					menu_level = 11;
					break;
				}
				case 11:
				{
					switch(pos11)
					{
						case 0: //YES
						{
							if(item_type == "weapon")
							{
								equip_weapon(option[8,pos8], pos8);
								num_weapon = array_length(option[8]);
								reset_weapon = true;
								menu_level = 2;
							}
							if(item_type == "armor")
							{
								equip_armor(option[9,pos9], pos9);
								num_armor = array_length(option[9]);
								reset_armor = true;
								menu_level = 2;
							}
							if(item_type == "accessory")
							{
								if(accessory_number == 1)
								{
									equip_accessory1(option[10,pos10], pos10);
									num_accessory = array_length(option[10]);
									reset_accessory = true;
									menu_level = 2;
								}
								if(accessory_number == 2)
								{
									equip_accessory2(option[10,pos10], pos10);
									num_accessory = array_length(option[10]);
									reset_accessory = true;
									menu_level = 2;
								}
							}
							break;
						}
						case 1: //NO
						{
							if(item_type == "weapon")
							{
								menu_level = 8;
							}
							if(item_type == "armor")
							{
								menu_level = 9;
							}
							if(item_type == "accessory")
							{
								menu_level = 10;
							}
							break;
						}
					}
				}
				case 12:
				{
					switch(pos12)
					{
						case 0: //YES
						{
							if(item_type == "item" ||item_type == "key_item")
							{
								option[6,pos6].use();
								option[6,pos6].stack -= 1;
								if option[6,pos6].stack <= 0
								{
									array_delete(obj_Item_Manager.inventory_item, pos6, 1);
								}
								num_item = array_length(option[6]);
								reset_item = true;
								menu_level = 1;
							}
							break;
						}
						case 1: //NO
						{
							if(item_type == "item")
							{
								menu_level = 6;
							}
							if(item_type == "key_item")
							{
								menu_level = 7;
							}
							break;
						}
					}
				}
			}
		}
		if(return_key)
		{
			switch(menu_level)
			{
				case 0: //MAIN MENU
				{
					obj_Player.show_menu = false;
					break;
				}
				case 1: //ITEMS
				{
					menu_level = 0;
					break;
				}
				case 2: //EQUIPS
				{
					menu_level = 0;
					break;
				}
				case 3: //SKILLS
				{
					menu_level = 0;
					break;
				}
				case 4: //STATS
				{
					menu_level = 0;
					break;
				}
				case 5: //OPTIONS
				{
					menu_level = 0;
					break;
				}
				case 6: //ITEM
				{
					menu_level = 1;
					break;
				}
				case 7: //KEY ITEM
				{
					menu_level = 1;
					break;
				}
				case 8: //WEAPON
				{
					pos8 = 0;
					menu_level = 2;
					break;
				}
				case 9: //ARMOR
				{
					pos9 = 0;
					menu_level = 2;
					break;
				}
				case 10: //ACCESSORY
				{
					pos10 = 0;
					menu_level = 2;
					break;
				}
				case 11: //CONFIRM
				{
					if(item_type == "weapon")
					{
						menu_level = 8;
					}
					if(item_type == "armor")
					{
						menu_level = 9;
					}
					if(item_type == "accessory")
					{
						menu_level = 10;
					}
					break;
				}
				case 12: //CONFIRM USE
				{
					if(item_type == "item")
					{
						menu_level = 6;
					}
					if(item_type == "key_item")
					{
						menu_level = 7;
					}
					break;
				}
			}
		}
	}
}
if(room_get_name(room) == "rom_Main_Menu")
{
	#region CURSOR
	main_menu_op_lenght = array_length(main_menu_option[0]);
	if(main_menu_level == 0)
	{
		main_menu_pos += down_key - up_key;
	}
	if(main_menu_pos < 0)
	{
		main_menu_pos = main_menu_op_lenght - 1;	
	}
	if(main_menu_pos > main_menu_op_lenght - 1)
	{
		main_menu_pos = 0;	
	}
	#endregion
	if(confirm_key)
	{
		switch(main_menu_level)
		{
			case 0:	//MAIN MENU
			{
				switch(main_menu_pos)
				{
					case 0:	//PLAY
					{
						room_goto_next();
						break;
					}
					case 1:	//OPTIONS
					{
						
						break;
					}
					case 2:	//QUIT
					{
						game_end();	
						break;
					}
				}
			}
		}
	}
}
