if interact == false
{
	other.x = target_x;
	other.y = target_y;
	obj_Camera.x = target_x;
	obj_Camera.y = target_y;
	room_goto(target_room);
}
else
{
	if(obj_Player.key_up)
	{
		other.x = target_x;
		other.y = target_y;
		obj_Camera.x = target_x;
		obj_Camera.y = target_y;
		room_goto(target_room);
	}
}