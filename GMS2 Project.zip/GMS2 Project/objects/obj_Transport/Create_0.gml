image_alpha = 0;
target_room = noone;
target_x = 0;
target_y = 0;
interact = false;