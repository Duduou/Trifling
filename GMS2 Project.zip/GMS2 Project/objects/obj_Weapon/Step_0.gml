image_xscale = obj_Player.image_xscale;
image_index = obj_Player.image_index;
x = playerx;
y = playery + 8;
#region STATE MACHINE
switch(state)
{
	case "idle" :
	{
		sprite_index = sprite_idle;
		break;	
	}
	case "walk" :
	{
		sprite_index = sprite_walk;
		break;	
	}
	case "jump":
	{
		sprite_index = sprite_jump;
		break;
	}
	case "crouch":
	{
		sprite_index = sprite_crouch;
		break;
	}
	case "crouch attack":
	{
		sprite_index = sprite_crouch_attack;
		break;
	}
	case "roll":
	{
		sprite_index = sprite_roll;
		break;
	}
	case "attack":
	{
		sprite_index = sprite_attack;
		break;
	}
	case "hurt":
	{
		sprite_index = sprite_hurt;
		break;
	}
	case "jump attack":
	{
		sprite_index = sprite_jump_attack;
		break;
	}
	case "death":
	{
		sprite_index = sprite_death;
		break;
	}
	case "wall slide":
	{
		sprite_index = sprite_wall_slide;
		break;
	}
}
#endregion
