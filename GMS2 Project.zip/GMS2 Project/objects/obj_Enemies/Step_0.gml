#region COLLISION AND MOVIMENT
var _hspd = sign(hspd);
var _vspd = sign(vspd);
ground = place_meeting(x-sign(image_xscale), y+1, obj_Wall);
if(instance_place(x, y+1, obj_Plataform))
{
	plataform = instance_place(x, y+1, obj_Plataform).bbox_top
}
else
{
	plataform = -1000000000000000000;	
}
if plataform == bbox_bottom && _vspd > 0
{
	ground = true;
}
if _hspd != 0
{
image_xscale = sign(hspd) * scale;
}
repeat (abs(hspd))
{
	if place_meeting(x+(hspd*2), y, obj_Wall)
	{
		if place_meeting(x, y, obj_Wall)
		{
			hspd = 0;
			break;
		}
	}
	if can_move == true
	{
	x += _hspd * spd;
	}
}
repeat (abs(vspd))
{
	if place_meeting(x-sign(image_xscale), y+_vspd, obj_Wall)
	{
		vspd = 0;
		break;
	}
	if _vspd > 0 && plataform
	{
		vspd = 0;
		break;
	}
	y += _vspd;
	y = floor(y);
}
if !ground 
	{
		if(vspd < max_vspd)
		{
		vspd += GRAV * mass;
		}
	}
else
{
	if jump
	{
		vspd = -jump_pow;;
	}
}
#endregion
image_yscale = scale;