if !place_meeting(x,y,obj_Player)
{
	image_alpha = lerp(image_alpha, 0, 0.1);
}
else
{
	image_alpha = lerp(image_alpha, 0.3, 0.1);
}