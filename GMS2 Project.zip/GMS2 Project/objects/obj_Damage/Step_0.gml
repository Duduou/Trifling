yy -= 0.1;
alpha -= 0.03;
if (alpha <= 0)
{
	instance_destroy()
}