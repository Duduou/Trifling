if(_yy)
{
	yy = target.y - target.sprite_height;
	dir = sign(target.image_xscale);
	_yy = false;
}
var _cx = camera_get_view_x(view_camera[0]);
var _cy = camera_get_view_y(view_camera[0]);
var _x = (xx - _cx) * _scalex;
var _y = (yy - _cy) * _scaley;
var color = color;
draw_set_font(fnt_Pixel_1);
draw_set_alpha(alpha)
if(is_player)
{
	var player_color = target.color_base 
	draw_text_outlined(_x - (_scalex * 6 * dir), _y + (_scaley * 2), c_white, player_color, damage, 2, 1, 1);
}
else
{
	draw_text_outlined(_x, _y - (_scaley * 3), c_white, c_black, damage, 2, 1, 1);
}
draw_set_alpha(1);