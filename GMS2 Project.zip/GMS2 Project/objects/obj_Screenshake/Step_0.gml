#region SHAKE
view_xport[0] = random_range(-shake, shake);
view_yport[0] = random_range(-shake, shake);
shake *= 0.90;
if(shake <= 0.2)
{
	instance_destroy();	
}
#endregion