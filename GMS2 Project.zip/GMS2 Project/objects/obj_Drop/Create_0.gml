/// @description Insert description here
// You can write your code in this editor
item = noone;
image_xscale = 0.5;
image_yscale = 0.5;
xx = x;
yy = y;
top = false;