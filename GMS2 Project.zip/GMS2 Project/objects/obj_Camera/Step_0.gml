if (target == noone) exit;
x = lerp(x,target.x + target.image_xscale * 3,0.1);
y = lerp(y,target.y-8,0.3);