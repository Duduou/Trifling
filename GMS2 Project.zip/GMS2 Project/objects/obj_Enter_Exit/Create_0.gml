image_alpha = 0;
out = true;
extern = noone;