if(place_meeting(bbox_right, y, obj_Player))
{
	out = true;
}
else if (place_meeting(bbox_left, y, obj_Player))
{
	out = false;	
}
if(!out)
{
	extern.image_alpha = lerp(extern.image_alpha,0,.2);	
	if(extern.image_alpha <= 0.4)
	{
		extern.image_alpha = 0;	
	}
}
if(out)
{
	extern.image_alpha = lerp(extern.image_alpha,1,.2);	
	if(extern.image_alpha >= 0.6)
	{
		extern.image_alpha = 1;	
	}
}