image_xscale = obj_Player.image_xscale;
image_alpha = obj_Player.image_alpha;
var hited_enemies = ds_list_create();
var amount = instance_place_list(x, y, obj_Enemies, hited_enemies,0);
var enemy;
for(var i = 0; i < amount; i++)
{
	var hited_enemy = hited_enemies[| i]
	var enemy_check = ds_list_find_index(enemy_list,hited_enemies)
	if(enemy_check == -1)
	{
		ds_list_add(enemy_list, hited_enemy)
	}
}

var size = ds_list_size(enemy_list);
for(var i = 0; i < size; i++)
{
	enemy = enemy_list[| i];
	if(enemy.state != "death")
	{
		enemy.state = "hurt";
		enemy.damage_physical = physical;
		enemy.damage_fire = fire;
		enemy.damage_water = water;
		enemy.damage_thunder = thunder;
		enemy.damage_nature = nature;
		enemy.hit = obj_Player.image_xscale;
		enemy.image_index = 0;
	}
}
if (image_speed > 0)
	{
		 if (image_index >= image_number - 1)
		 {
			image_speed = 0; 
		 }
	}
if (image_speed == 0)
{
ds_list_destroy(hited_enemies);
ds_list_destroy(enemy_list);
instance_destroy(id);
}