#region CONTROLS
key_right = keyboard_check(ord("D"));
key_left = keyboard_check(ord("A"));
key_up = keyboard_check(ord("W"));
key_down = keyboard_check(ord("S"));
if can_move == true
{
	key_jump = keyboard_check_pressed(vk_space);
}
if can_move == true
{
	key_attack = keyboard_check(ord("J"));
}
#endregion
#region COLLISION AND MOVIMENT
var _hspd = sign(hspd);
var _vspd = sign(vspd);
ground = place_meeting(x-sign(image_xscale), y + 1, obj_Wall);
if !(key_down && key_jump)
{
	if(instance_place(x, y+2, obj_Plataform))
	{
		plataform = instance_place(x, y+2, obj_Plataform).bbox_top
	}
	else
	{
		plataform = -1000000000000000000;	
	}
	if plataform == bbox_bottom && _vspd > 0
	{
		ground = true;
	}
}
else if(plataform == bbox_bottom)
{
	y += 0.0001;
	can_move = true;
	state = "jump";
	image_index = 0;
}
hspd =key_right - key_left;
if _hspd != 0 && can_turn = true
{
image_xscale = _hspd;
}
repeat (abs(hspd))
{
	if place_meeting(x+(hspd*2), y, obj_Wall)
	{
		if place_meeting(x, y, obj_Wall)
		{
			hspd = 0;
			break;
		}
	}
	if can_move == true
	{
	x+=_hspd * spd;
	}
}
repeat (abs(vspd))
{
	if place_meeting(x-sign(image_xscale), y+_vspd, obj_Wall)
	{
		vspd = 0;
		break;
	}
	if _vspd > 0 && plataform == bbox_bottom
	{
		vspd = 0;
		break;
	}
	y += _vspd;
	y = floor(y);
}
if !ground 
	{
		if(vspd < max_vspd)
		{
		vspd += GRAV * mass;
		}
	}
else
{
	if key_jump
	{
		vspd = -jump_pow;;
	}
}
#endregion
#region COMBAT
if(invencible && invencible_time > 0)
{
	invencible_time --;
	image_alpha = min(max(sin(get_timer()/30000),0.2),0.8)
}
else
{
	invencible = false;
	image_alpha = 1;
}
#endregion