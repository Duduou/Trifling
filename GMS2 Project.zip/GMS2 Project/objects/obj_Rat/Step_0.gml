event_inherited();
if(hitted && obj_Player.state != "death")
{
	if(x >= obj_Player.x - 1 && x <= obj_Player.x + 1)
	{
		hspd = 0;
	}
	else
	{
		hspd = sign(obj_Player.x - x);
	}
}
#region MELEE
melee = instance_place(x, y, obj_Player)
if(melee != noone)
{
	if(melee.invencible == false && melee.rolling == false)
	{
		if(melee.state != "death")
		{
		melee.state = "hurt";
		melee.damage_physical = atk_physical;
		melee.damage_fire = atk_fire;
		melee.damage_water = atk_water;
		melee.damage_thunder = atk_thunder;
		melee.damage_nature = atk_nature;
		melee.hit = sign(melee.x - x);
		melee.image_index = 0;
		}
	}
}
if(!hitted || obj_Player.state == "death")
{
	if !place_meeting(x+(sign(image_xscale)*6), y+1, obj_Wall) && !place_meeting(x+(sign(image_xscale)*6), y+1, obj_Plataform)
	{
		hspd = 0;
		border = true;
	}
	else
	{
		border = false;	
	}
	if timer <= 0
	{
		timer = irandom_range(30,40)
		if(border)
		{
			hspd = choose(0, -sign(image_xscale));
		}
		else
		{
			hspd = choose(-1, 0, 1);
		}
	}
}
timer--;
#endregion
#region STATE MACHINE
switch(state)
{
	case "idle":
	{
		image_speed = 1;
		sprite_index = spr_Rat_Idle
		break;
	}
	case "hurt":
	{
		damage = (damage_physical - def_physical) + (damage_fire - def_fire) + (damage_water - def_water) + (damage_thunder - def_thunder) + (damage_nature - def_nature)
		if(show_damage == true)
		{
			var _damage = instance_create_layer(x, y, "Attack", obj_Damage);
			_damage.damage = damage;
			_damage.target = id;
			show_damage = false;
		}
		screenshake(0.7);
		can_move = false;
		image_xscale = -hit * scale;
		image_speed = 1;
		sprite_index = spr_Rat_Hurt;
		if(life - damage <= 0)
		{
			state = "death";
			image_index = 0;
			screenshake(1);
		}
		else
		{
			if(!place_meeting(x-(image_xscale*2), y, obj_Wall) && state != "death")
			{
				y -= 0.3;
				x += hit/2;
			}
			if (image_speed > 0)
			{
				if (image_index >= image_number - 1)
				{
					show_damage = true;
					life -= damage;
					image_speed = 0;
					can_move = true;
					hitted = true;
					state = "idle";
					sprite_index = spr_Rat_Idle
					image_index = 0;
				}
			}
		}
		break;
	}
	case "death":
	{
		can_move = false;
		image_xscale = -hit * scale;
		image_speed = 1;
		sprite_index = spr_Rat_Death;
		if(!place_meeting(x+hspd, y, obj_Wall))
		{
			y -= 0.1;
			x += hit/2;
		}
		if(place_meeting(x+hspd, y, obj_Wall))
		{
			x -= hit;
		}
		if (image_speed > 0)
		{
			image_alpha = lerp(1, 0, .4)
			if (image_index >= image_number - 1)
			{
				instance_deactivate_object(id);
				instance_destroy(id);
			}
		}
		break;
	}
}
#endregion

